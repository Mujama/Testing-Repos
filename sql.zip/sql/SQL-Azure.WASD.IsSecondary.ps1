﻿if(!(Test-Path variable:\Warn)){[double]$Warn=90}
if(!(Test-Path variable:\Crit)){[double]$Crit=95}

try{


if(!(Test-Path variable:\AzureAccount)){throw "Azure Account Not Provided"}
if(!(Test-Path variable:\AzurePassword)){throw "Azure Password Not Provided"}
if(!(Test-Path variable:\AzureHostName)){throw "Azure HostName Not Provided"}
if(!(Test-Path variable:\DatabaseName)){throw "Azure DatabaseName Not Provided"}
$ServerName = $AzureHostName.Split('.')[0]
$AzureSecret = ConvertTo-SecureString $AzurePassword -AsPlainText -Force
$AzureCred = New-Object System.Management.Automation.PSCredential($AzureAccount, $AzureSecret)

Add-AzureAccount -Credential $AzureCred | Out-Null


$db = (Get-AzureSqlDatabaseCopy -ServerName $Servername -DatabaseName $DatabaseName)
if($db.IsLocalDatabaseReplicationTarget -eq $true)
{$State = 0}
else {$state = 2}


$OutXML = @"
{1},{0} IsSecondary: {2}|<Data><Instance Name="{0}" Type="Database" State="{1}"><Value UofM="" Name="IsSecondary">{2}</Value></Instance></Data>
"@

[string]::Format($OutXML, $DatabaseName, $State, $(if($db.IsLocalDatabaseReplicationTarget -eq $true){1}else{0}))

Remove-AzureAccount $AzureAccount -Force -WarningAction SilentlyContinue | Out-Null
}
catch
{[string]::Format('3|<Data><Instance Name="default"><Value UofM="" Name="Error">{0}</Value></Instance></Data>',$("$($_.Exception);$($_.InvocationInfo.ScriptLineNumber))".Replace('&', '&amp;').Replace('<', '&lt;').Replace('>', '&gt;')));throw}




