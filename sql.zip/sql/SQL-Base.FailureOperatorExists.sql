/*######################################
SQL-Base.FailureOperatorExists			
Author: Frank Gill
Created: 20140409
Validated Versions: 2005, 2008, 2008R2, 2012
Validated Editions: Standard, Enterprise

Synopsis: Checks for the existence of a 
Failure Operator for each agent job on the 
instance.

######################################*/
SET NOCOUNT ON
BEGIN TRY


DECLARE @jobname SYSNAME
DECLARE @operatorname SYSNAME
DECLARE @loopcount SMALLINT
DECLARE @looplimit SMALLINT
DECLARE @sqlstr VARCHAR(2000)
DECLARE @State CHAR(1)

CREATE TABLE #Instance
    (
     InstanceID INT IDENTITY(1, 1)
                    NOT NULL,
     InstanceName NVARCHAR(1000) NOT NULL,
     InstanceType NVARCHAR(100) NULL,
     InstanceState NVARCHAR(100) NULL,
     InstanceStatus NVARCHAR(100) NULL
    )

CREATE TABLE #Value
    (
     ValueID INT IDENTITY(1, 1)
                 NOT NULL,
     InstanceID INT NOT NULL,
     ValueName NVARCHAR(1000) NOT NULL,
     ValueUofM NVARCHAR(100) NOT NULL,
	 [Value] NVARCHAR(1000) NOT NULL,
	 ValueCritical NVARCHAR(100) NULL,
	 ValueWarning NVARCHAR(100) NULL
    )

SET @loopcount = 1

--Drop temp table if it exists
IF EXISTS(SELECT 1 FROM tempdb.sys.objects WHERE name LIKE '%#notificationtype%')
BEGIN

	DROP TABLE #notificationtype

END

--Select all jobs and associate operators, if they exist
SELECT j.name AS jobname, 
j.enabled AS jobenabled,
o.id AS operatorid,
o.name AS operatorname,
o.email_address AS operatoremail,
j.notify_level_email AS notifyemail,
o.pager_address AS pageremail,
j.notify_level_page AS notifypager
INTO #notificationtype
FROM msdb.dbo.sysjobs j
LEFT OUTER JOIN msdb.dbo.sysoperators o
ON (j.notify_email_operator_id = o.id
	AND j.notify_level_email = 2)
OR (j.notify_page_operator_id = o.id
	AND j.notify_level_page = 2)

/*
If an email operator and pager operator both exist
for a job, delete the pager operator
*/
DELETE FROM #notificationtype
WHERE operatoremail IS NULL
AND notifyemail = 2

/*
Insert Instances into #Instance Table Here
INSERT INTO #Instance (InstanceName, InstanceType, InstanceState, InstanceStatus)
*/

/*
If no failure operator exists, set the instance state to 1
*/
INSERT INTO #Instance (InstanceName, InstanceType, InstanceState, InstanceStatus)
SELECT  
jobname, 
'JobName', 
CASE 
WHEN operatoremail IS NULL AND pageremail IS NULL
	THEN 1
	ELSE 0
END, 
NULL
FROM #notificationtype

/*
Insert Values for Each Instance Here
INSERT INTO #Value (InstanceID, ValueName, ValueUofM, [Value], ValueCritical, ValueWarning)
*/
INSERT INTO #Value (InstanceID, ValueName, ValueUofM, [Value], ValueCritical, ValueWarning)
SELECT i.InstanceID, 'JobOperator', '', COALESCE(n.operatorname,'None'), NULL, NULL
FROM #Instance i JOIN #notificationtype n ON i.InstanceName = n.jobname

INSERT INTO #Value (InstanceID, ValueName, ValueUofM, [Value], ValueCritical, ValueWarning)
SELECT i.InstanceID, 'OperatorType', '', 
CASE
WHEN n.operatoremail IS NOT NULL AND n.notifyemail = 2
THEN 'email'
WHEN n.pageremail IS NOT NULL AND n.notifypager = 2
THEN 'pager'
ELSE 'none'
END,
NULL, NULL
FROM #Instance i
INNER JOIN #notificationtype n
ON i.InstanceName = n.jobname

DECLARE @x XML 
			
            SET @x=(SELECT  (SELECT i.InstanceName AS [Instance/@Name],
                                    i.InstanceType AS [Instance/@Type],
                                    i.InstanceState AS [Instance/@State],
									i.InstanceStatus AS [Instance/@Status],
									(SELECT v.ValueName AS [Value/@Name],
									v.ValueUofM AS [Value/@UofM],
									v.ValueCritical AS [Value/@Critical],
									v.ValueWarning AS [Value/@Warning],
									v.[Value] AS [Value]
									FROM #Value v
									WHERE v.InstanceID = i.InstanceID
									FOR XML PATH(''), TYPE
									) AS [Instance]
                FROM #Instance i
				FOR XML PATH(''), ROOT('Data'),
                        TYPE))

SELECT @State = MAX(InstanceState) FROM #Instance

DROP TABLE #Instance
DROP TABLE #Value

SELECT  ISNULL(@State, '3')+'|'+ISNULL(CAST(@x AS NVARCHAR(MAX)), N'<Data><Instance Name="Unknown"><Value Name="Unknown" UofM=""/></Instance></Data>') AS StringValue


END TRY
BEGIN CATCH
			
		/*http://msdn.microsoft.com/en-us/library/ms179296%28v=SQL.105%29.aspx*/

    DECLARE @ErrorMessage NVARCHAR(4000),
        @ErrorNumber INT,
        @ErrorSeverity INT,
        @ErrorState INT,
        @ErrorLine INT,
        @ErrorProcedure NVARCHAR(200);

    /*Assign variables to error-handling functions that 
     capture information for RAISERROR.*/
    SELECT  @ErrorNumber=ERROR_NUMBER(),
            @ErrorSeverity=ERROR_SEVERITY(),
            @ErrorState=ERROR_STATE(),
            @ErrorLine=ERROR_LINE(),
            @ErrorProcedure=ISNULL(ERROR_PROCEDURE(), '-');

	/*Build the message string that will contain original
     error information.*/
    SELECT  @ErrorMessage=N'Error %d, Level %d, State %d, Procedure %s, Line %d, '+'Message: '+ERROR_MESSAGE();

    SELECT  '3|<Data><Instance Name="default" Type="SQL"><Value Name="Error" UofM="">'+REPLACE(REPLACE(REPLACE(REPLACE(@ErrorMessage, '&', '&amp;'), '<', '&lt;'),
                                                                                                       '>', '&gt;'),
                                                                                               'Error %d, Level %d, State %d, Procedure %s, Line %d, Message: ',
                                                                                               '')+'</Value></Instance></Data>' AS StringValue

    

    /*Raise an error: msg_str parameter of RAISERROR will contain
     the original error information.*/
    RAISERROR 
        (
        @ErrorMessage, 
        @ErrorSeverity, 
        1,               
        @ErrorNumber,    /* parameter: original error number.*/
        @ErrorSeverity,  /* parameter: original error severity.*/
        @ErrorState,     /* parameter: original error state.*/
        @ErrorProcedure, /* parameter: original error procedure name.*/
        @ErrorLine       /* parameter: original error line number.*/
        );

END CATCH
