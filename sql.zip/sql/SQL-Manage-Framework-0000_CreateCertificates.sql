SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET NUMERIC_ROUNDABORT OFF
SET QUOTED_IDENTIFIER ON

SET NOCOUNT ON



BEGIN TRY
	
    DECLARE @SQLToExecute NVARCHAR(MAX)

    SELECT  @SQLToExecute='
	USE master

DECLARE @PKPwd NVARCHAR(1000) ,
    @PKDPwd NVARCHAR(1000) ,
    @CertCommand NVARCHAR(4000)

DECLARE @CertLocation NVARCHAR(1000) ,
    @CertKeyPath NVARCHAR(1000) ,
    @CertPKeyPath NVARCHAR(1000) ,
    @CertKeyPassword NVARCHAR(1000) ,
    @CertPKeyPassword NVARCHAR(1000)


DECLARE @IsXPCmd INT ,
    @IsShowAdvanced INT ,
    @DelCmd NVARCHAR(4000)


SELECT  @PKPwd = ''!!!All you need is love.Dun D D D Dun.'' ,
        @PKDPwd = ''AND IF tomorrow NEVER Comes! - Will you still say I LOVE you!''

IF NOT EXISTS ( SELECT  name
                FROM    sys.certificates
                WHERE   name = ''Apparatus_SigningCert'' )
    BEGIN
        SELECT  @CertCommand = ''CREATE CERTIFICATE Apparatus_SigningCert
	   ENCRYPTION BY PASSWORD = '''''' + @PKPwd
                + ''''''
	   WITH SUBJECT = ''''Certificate created by Apparatus to facilitate Least Privilege Framework. !!! DO NOT REMOVE !!!'''',
	   START_DATE = ''''20160101'''', EXPIRY_DATE = ''''20300101'''';''

        --PRINT @CertCommand
        EXEC(@CertCommand)
    END

IF EXISTS ( SELECT  name
            FROM    sys.server_principals
            WHERE   name = ''Apparatus_SigningLogin'' )
    BEGIN
        DROP LOGIN Apparatus_SigningLogin
    END
	
CREATE LOGIN Apparatus_signingLogin FROM CERTIFICATE Apparatus_SigningCert
EXEC sp_addsrvrolemember ''Apparatus_SigningLogin'', ''sysadmin''
GRANT CONTROL SERVER TO Apparatus_SigningLogin
REVOKE CONNECT SQL TO Apparatus_SigningLogin

IF NOT EXISTS ( SELECT  name
                FROM    Apparatus_DBA.sys.certificates
                WHERE   name = ''Apparatus_SigningExecutionCert'' )
    BEGIN
        SELECT  @CertLocation = REPLACE(physical_name, ''master.mdf'', '''')
        FROM    sys.master_files
        WHERE   database_id = 1
                AND file_id = 1

        SELECT  @CertKeyPath = @CertLocation + ''Apparatus_.bak'' ,
                @CertPKeyPath = @CertLocation + ''Apparatus_P.bak''

        SELECT  @CertCommand = ''BACKUP CERTIFICATE Apparatus_SigningCert TO FILE = ''''''
                + @CertKeyPath + '''''' WITH PRIVATE KEY (FILE = ''''''
                + @CertPKeyPath + '''''', ENCRYPTION BY PASSWORD = '''''' + @PKDPwd
                + '''''', DECRYPTION BY PASSWORD = '''''' + @PKPwd + '''''')''

        --PRINT @CertCommand
        EXEC(@CertCommand)

        USE Apparatus_DBA

		IF NOT EXISTS(SELECT name FROM sys.symmetric_keys WHERE name = ''##MS_DatabaseMasterKey##'')
		BEGIN
			SELECT @CertCommand = ''CREATE MASTER KEY ENCRYPTION BY PASSWORD = ''''''+@PKPwd+'''''';''

			--PRINT @CertCommand
			EXEC(@CertCommand)
		END

        SELECT  @CertCommand = ''CREATE CERTIFICATE Apparatus_SigningExecutionCert FROM FILE =''''''
                + @CertKeyPath + ''''''
	  WITH PRIVATE KEY(FILE='''''' + @CertPKeyPath
                + '''''', DECRYPTION BY PASSWORD='''''' + @PKDPwd + '''''')''

        --PRINT @CertCommand
        EXEC(@CertCommand)

        SELECT  @IsXPCmd = CAST(value AS INT)
        FROM    sys.configurations
        WHERE   name = ''xp_cmdshell''

        IF @IsXPCmd = 0
            BEGIN
	
                SELECT  @IsShowAdvanced = CAST(value AS INT)
                FROM    sys.configurations
                WHERE   name = ''show advanced options''

                IF @IsShowAdvanced = 0
                    BEGIN
                        EXEC sp_configure ''show advanced options'', 1
                        RECONFIGURE
                    END
	
                EXEC sp_configure ''xp_cmdshell'', 1
                RECONFIGURE

            END
        SELECT  @DelCmd = ''del "'' + @CertKeyPath + ''"''
        EXEC xp_cmdshell @DelCmd, no_output
        SELECT  @DelCmd = ''del "'' + @CertPKeyPath + ''"''
        EXEC xp_cmdshell @DelCmd, no_output

        IF @IsXPCmd = 0
            BEGIN
                EXEC sp_configure ''xp_cmdshell'', 0
                RECONFIGURE
            END

        IF @IsShowAdvanced = 0
            BEGIN
                EXEC sp_configure ''show advanced options'', 0
                RECONFIGURE
            END
    END
	'

    EXEC(@SQLToExecute)

	SELECT '0,ExecutionSuccessful|<Data><Instance Name="Execution"><Value Name="ExecutionComplete" UofM="">1</Value></Instance></Data>' AS StringValue

END TRY
BEGIN CATCH
			
		/*http://msdn.microsoft.com/en-us/library/ms179296%28v=SQL.105%29.aspx*/

    DECLARE @ErrorMessage NVARCHAR(4000),
        @ErrorNumber INT,
        @ErrorSeverity INT,
        @ErrorState INT,
        @ErrorLine INT,
        @ErrorProcedure NVARCHAR(200);

    /*Assign variables to error-handling functions that 
     capture information for RAISERROR.*/
    SELECT  @ErrorNumber=ERROR_NUMBER(),
            @ErrorSeverity=ERROR_SEVERITY(),
            @ErrorState=ERROR_STATE(),
            @ErrorLine=ERROR_LINE(),
            @ErrorProcedure=ISNULL(ERROR_PROCEDURE(), '-');

	/*Build the message string that will contain original
     error information.*/
    SELECT  @ErrorMessage=N''+ERROR_MESSAGE();

    SELECT  '1,ExecutionFailed:'+@ErrorMessage+'|<Data><Instance Name="Execution"><Value Name="ExecutionComplete" UofM="">0</Value></Instance></Data>' AS StringValue

END CATCH