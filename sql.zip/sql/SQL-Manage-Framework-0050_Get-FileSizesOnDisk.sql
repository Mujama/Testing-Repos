SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET NUMERIC_ROUNDABORT OFF
SET QUOTED_IDENTIFIER ON

SET NOCOUNT ON

BEGIN TRY
/*Make Certain we're in the Apparatus_DBA database - if we're not - ABORT!*/
    IF DB_NAME() <> 'Apparatus_DBA'
        BEGIN
            SELECT  '1,ExecutionFailed:Database Context Incorrect|<Data><Instance Name="Execution"><Value Name="ExecutionComplete" UofM="">0</Value></Instance></Data>' AS StringValue
            RETURN
        END	

    DECLARE @SQLToExecute NVARCHAR(MAX)
	
    IF EXISTS ( SELECT  *
                FROM    INFORMATION_SCHEMA.ROUTINES
                WHERE   SPECIFIC_SCHEMA = N'DBA'
                        AND SPECIFIC_NAME = N'Get_FileSizesOnDisk' )
        DROP PROCEDURE DBA.Get_FileSizesOnDisk

    SELECT  @SQLToExecute = 'CREATE PROCEDURE DBA.Get_FileSizesOnDisk
@FolderPath VARCHAR(255) = '''',
@DisplayPoSh BIT = 1,
/* @noexec = 1 will print the dynamic SQL string rather than execute it 
   @noexec must be the last parameter in your stored procedure
   Add all parameters before @noexec */ @noexec BIT=0
   WITH ENCRYPTION
AS
    BEGIN TRY
	
	/* Declare local variables necessary for logging and error reporting */
        DECLARE @currentuser SYSNAME
        DECLARE @currenttimestamp DATETIME
        DECLARE @procedurename SYSNAME 
        DECLARE @sqlstr NVARCHAR(2000) 
        DECLARE @errormsg VARCHAR(2000)
	
	/* Initialize local variables */
        SELECT  @currentuser=ORIGINAL_LOGIN(),
                @currenttimestamp=CURRENT_TIMESTAMP,
                @procedurename=N''Get_FileSizesOnDisk'',
                @sqlstr=''''

				
	/* Code for procedure goes below this line */

        CREATE TABLE #SpaceUsed
            (
             DBName SYSNAME,
             DBSIze VARCHAR(100),
             SpaceUsed VARCHAR(100),
             FileType VARCHAR(100),
             FileName SYSNAME,
             Physical_Name NVARCHAR(2000),
             SizeMB NUMERIC(18, 4),
             SpaceUsedMB NUMERIC(18, 4),
             FreeSpaceMB NUMERIC(18, 4)
            ) 

        DECLARE csrDB CURSOR FAST_FORWARD LOCAL
        FOR
            SELECT  name
            FROM    sys.databases
            WHERE   database_id IN (SELECT  database_id
                                    FROM    sys.master_files
                                    WHERE   physical_name LIKE ''%''+@FolderPath+''%'')

        DECLARE @dbname SYSNAME,
            @sql NVARCHAR(4000)


        OPEN csrDB
        FETCH NEXT FROM csrDB INTO @dbname

        WHILE @@fetch_status=0
            BEGIN


                SELECT  @sql=''USE ''+QUOTENAME(@dbname)+'';
				INSERT  INTO #SPACEUSED
						(
						 dbname,
						 dbsize,
						 SpaceUsed,
						 FileType,
						 FileName,
						 Physical_Name,
						 SizeMB,
						 SpaceUsedMB,
						 FreeSpaceMB
						)
						SELECT
							''''''+@dbname+'''''',
							size,
							FILEPROPERTY(name, ''''SpaceUsed''''),
							type_desc,
							name,
							Physical_Name,
							size * 8 / 1024.00,
							FILEPROPERTY(name, ''''SpaceUsed'''') * 8 / 1024,
							(size * 8 / 1024.00) - (FILEPROPERTY(name, ''''SpaceUsed'''') * 8 / 1024)
						FROM
							sys.database_files''

                EXEC(@sql)

                FETCH NEXT FROM csrDB INTO @dbname
            END

        CLOSE csrDB
        DEALLOCATE csrDB

        SELECT  FreeSpaceMB,
                SizeMB,
                SpaceUsedMB,
                DBName,
                Physical_Name,
                FileType,
                ''USE ''+QUOTENAME(DBName)+'';DBCC SHRINKFILE(''''''+FileName+'''''', ''+REPLACE(SpaceUsedMB, ''.0000'', '''')+'');''
        FROM    #SpaceUsed
        WHERE   Physical_Name LIKE ''%''+@FolderPath+''%''
        ORDER BY FreeSpaceMB DESC
        
        IF @DisplayPosh = 1
        SELECT  ''gwmi win32_volume -computername ''+CAST(SERVERPROPERTY(''ComputerNamePhysicalNetBios'') AS NVARCHAR(100))
                +'' | select name,@{Name=''''FreeSpaceGB'''';Expression={$_.FreeSpace/1GB}}, @{Name=''''CapacityGB'''';Expression={$_.Capacity/1GB}}, @{Name=''''PctFree'''';Expression={$_.FreeSpace/$_.Capacity*100}} | sort-object PctFree -desc'' AS [PoSH FreeSpace]


	/* Code for procedure goes above this line */


	
	/* Execute InsertActivityLog to track executions of the stored procedure */
        EXECUTE DBA.InsertActivityLog
            @currenttimestamp,
            @currentuser,
            @procedurename,
            @sqlstr

    END TRY
 
    BEGIN CATCH
/* Derived from http://msdn.microsoft.com/en-us/library/ms179296%28v=SQL.105%29.aspx */
 
        DECLARE @ErrorMessage NVARCHAR(4000),
            @ErrorNumber INT,
            @ErrorSeverity INT,
            @ErrorState INT,
            @ErrorLine INT,
            @ErrorProcedure NVARCHAR(200);
 
    /* Assign variables to error-handling functions that capture information for RAISERROR. */
        SELECT  @ErrorNumber=ERROR_NUMBER(),
                @ErrorSeverity=ERROR_SEVERITY(),
                @ErrorState=ERROR_STATE(),
                @ErrorLine=ERROR_LINE(),
                @ErrorProcedure=ISNULL(ERROR_PROCEDURE(), ''-'');
 
    /*Build the message string that will contain original error information.*/
    
	SELECT  @ErrorMessage=ERROR_MESSAGE();    
	
	/* Execute InsertActivityLog to track executions of the stored procedure and error information */
        EXECUTE DBA.InsertActivityLog
            @currenttimestamp,
            @currentuser,
            @procedurename,
            @sqlstr,
            @ErrorMessage
 
	SELECT  @ErrorMessage=N''Error %d, Level %d, State %d, Procedure %s, Line %d, ''+''Message: ''+ERROR_MESSAGE();

    /*Raise an error: msg_str parameter of RAISERROR will contain the original error information.*/
        RAISERROR 
        (
        @ErrorMessage, 
        @ErrorSeverity, 
        1,               
        @ErrorNumber,
        @ErrorSeverity,
        @ErrorState,
        @ErrorProcedure,
        @ErrorLine
        );
 
    END CATCH'

    EXEC(@SQLToExecute)

	IF EXISTS(SELECT 1 FROM sys.certificates WHERE name = 'Apparatus_SigningExecutionCert')
	BEGIN
		SELECT @SQLToExecute = 'ADD SIGNATURE TO DBA.[Get_FileSizesOnDisk] BY CERTIFICATE [Apparatus_SigningExecutionCert]'
		EXEC(@SQLToExecute)
	END

    SELECT  '0,ExecutionSuccessful|<Data><Instance Name="Execution"><Value Name="ExecutionComplete" UofM="">1</Value></Instance></Data>' AS StringValue

END TRY
BEGIN CATCH
			
		/*http://msdn.microsoft.com/en-us/library/ms179296%28v=SQL.105%29.aspx*/

    DECLARE @ErrorMessage NVARCHAR(4000) ,
        @ErrorNumber INT ,
        @ErrorSeverity INT ,
        @ErrorState INT ,
        @ErrorLine INT ,
        @ErrorProcedure NVARCHAR(200);

    /*Assign variables to error-handling functions that 
     capture information for RAISERROR.*/
    SELECT  @ErrorNumber = ERROR_NUMBER() ,
            @ErrorSeverity = ERROR_SEVERITY() ,
            @ErrorState = ERROR_STATE() ,
            @ErrorLine = ERROR_LINE() ,
            @ErrorProcedure = ISNULL(ERROR_PROCEDURE(), '-');

	/*Build the message string that will contain original
     error information.*/
    SELECT  @ErrorMessage = N'' + ERROR_MESSAGE();

    SELECT  '2,ExecutionFailed:' + @ErrorMessage
            + '|<Data><Instance Name="Execution"><Value Name="ExecutionComplete" UofM="">0</Value></Instance></Data>' AS StringValue

END CATCH