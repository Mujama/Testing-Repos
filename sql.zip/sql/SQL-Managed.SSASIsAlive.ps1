if(!(Test-Path variable:\Instance)){[string]$Instance="DEFAULT"}

$ErrorActionPreference = "Stop"
Set-Alias AM Add-Member
Set-Alias NOB New-Object
$SP = "ScriptProperty"

function EscValue{param($Val);$Val.Replace('&','&amp;').Replace('<','&lt;').Replace('>','&gt;')}

function InstanceValue{param($Name,$UofM,[string]$Value,$Warn,$Crit)
NOB PSObject -Prop (@{'Name'=$Name;'UofM'=$UofM;'Value'=$Value.ToString();'Warn'=$Warn;'Crit'=$Crit}) |
AM $SP ToXML {[string]::Format('<Value Name="{0}" UofM="{1}" Warning="{2}" Critical="{3}">{4}</Value>',$this.Name,$this.UofM,$this.Warn,$this.Crit,$(EscValue $this.Value))} -Pass -Force}

function Instance{param($Name,$Type,$State)
NOB PSObject -Prop (@{'Name'=$Name;'Type'=$Type;'State'=$State;'Values'=[PSObject[]]""}) |
AM ScriptMethod AddValue {param($Value)$this.Values+=$Value} -Pass |
AM $SP ToXML {[string]::Format('<Instance Name="{0}" Type="{1}" State="{2}">{3}</Instance>',$this.Name,$this.Type,$this.State,$(@(foreach($v in $this.Values){$v.ToXml}) -join ""))} -Pass}

function Out-Kore{param([int]$State,[PSObject[]]$Instances,$ShortText)
[string]::Format("{0}{2}|<Data>{1}</Data>",$State,$(@(foreach($I in $Instances){$I.ToXml}) -join ""), $(if($ShortText -ne $null){",$ShortText"}else{""}))}
try{
if($Instance -eq "DEFAULT")
{$SvcName="MSSQLServerOLAPService";}
else{$SvcName="MSOLAP`$$($Instance)"}


try{
$svc = (gwmi win32_service -Filter "Name='$SvcName'" -ErrorAction Stop)
if($svc -and $svc.State -eq "Running"){$Ret=0}else{$Ret=1}
}catch{$Ret=1}

	switch($Ret)
	{0{$Return=0;$Short="Success"}
	1{$Return=2;$Short="SSAS Service Unavailable or Not Running"}
	default {Write-Error "Unknown Return State"}}
$I = Instance "SSAS" "SQL-Service" $Return
$I.AddValue((InstanceValue "State" "" $(if($svc){$svc.State}else{"UNKNOWN"})))
Out-Kore $Return $I $Short
}catch{[string]::Format('3,ERROR IN POWERSHELL|<Data><Instance Name="default"><Value UofM="" Name="Error">{0}</Value></Instance></Data>',$(EscValue "$($_.Exception);$($_.InvocationInfo.ScriptLineNumber))"));throw}
