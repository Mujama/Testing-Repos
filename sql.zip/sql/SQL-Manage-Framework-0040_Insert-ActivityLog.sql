SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET NUMERIC_ROUNDABORT OFF
SET QUOTED_IDENTIFIER ON

SET NOCOUNT ON

BEGIN TRY
/*Make Certain we're in the Apparatus_DBA database - if we're not - ABORT!*/
    IF DB_NAME() <> 'Apparatus_DBA'
        BEGIN
            SELECT  '1,ExecutionFailed:Database Context Incorrect|<Data><Instance Name="Execution"><Value Name="ExecutionComplete" UofM="">0</Value></Instance></Data>' AS StringValue
            RETURN
        END	

    DECLARE @SQLToExecute NVARCHAR(MAX)
	
    IF EXISTS ( SELECT  1
                FROM    INFORMATION_SCHEMA.ROUTINES
                WHERE   SPECIFIC_SCHEMA = N'DBA'
                        AND SPECIFIC_NAME = N'InsertActivityLog' )
        DROP PROCEDURE DBA.InsertActivityLog

    SELECT  @SQLToExecute = 'CREATE PROCEDURE DBA.InsertActivityLog
    @executiontime DATETIME ,
    @loginname SYSNAME ,
    @procedureexecuted SYSNAME ,
    @dynamicsql VARCHAR(2000) ,
    @errormsg NVARCHAR(4000) = NULL
    WITH ENCRYPTION
AS
    BEGIN TRY

        DECLARE @currentuser SYSNAME
        DECLARE @currenttimestamp DATETIME
        DECLARE @procedurename SYSNAME 
        DECLARE @sqlstr VARCHAR(2000) 
	
	/* Initialize local variables */
        SELECT  @currentuser = ORIGINAL_LOGIN() ,
                @currenttimestamp = CURRENT_TIMESTAMP ,
                @procedurename = N''DBA.InsertActivityLog'' ,
                @sqlstr = ''''

        IF @executiontime IS NULL
            BEGIN

                SET @errormsg = ''@executiontime cannot be null.  Please check the input parameters and execute again.''

                RAISERROR (@errormsg,
					16,
					1);						
		
            END

        IF @loginname IS NULL
            BEGIN

                SET @errormsg = ''@loginname cannot be null.  Please check the input parameters and execute again.''

                RAISERROR (@errormsg,
					16,
					1);						
		
            END

        IF @procedureexecuted IS NULL
            BEGIN

                SET @errormsg = ''@procedureexecuted cannot be null.  Please check the input parameters and execute again.''

                RAISERROR (@errormsg,
					16,
					1);						
		
            END

        INSERT  INTO DBA.ActivityLog
                ( ExecutionTime ,
                  LoginName ,
                  ProcedureExecuted ,
                  DynamicSQL ,
                  ErrorMsg
                )
        VALUES  ( @executiontime ,
                  @loginname ,
                  @procedureexecuted ,
                  @dynamicsql ,
                  @ErrorMsg
                )

    END TRY
    BEGIN CATCH

/* Derived from http://msdn.microsoft.com/en-us/library/ms179296%28v=SQL.105%29.aspx */
 
        DECLARE @ErrorMessage NVARCHAR(4000) ,
            @ErrorNumber INT ,
            @ErrorSeverity INT ,
            @ErrorState INT ,
            @ErrorLine INT ,
            @ErrorProcedure NVARCHAR(200);
 
    /* Assign variables to error-handling functions that capture information for RAISERROR. */
        SELECT  @ErrorNumber = ERROR_NUMBER() ,
                @ErrorSeverity = ERROR_SEVERITY() ,
                @ErrorState = ERROR_STATE() ,
                @ErrorLine = ERROR_LINE() ,
                @ErrorProcedure = ISNULL(ERROR_PROCEDURE(), ''-'');
 
    /*Build the message string that will contain original error information.*/
        SELECT  @ErrorMessage = N''Error %d, Level %d, State %d, Procedure %s, Line %d, ''
                + ''Message: '' + ERROR_MESSAGE();
	
	/* Execute InsertActivityLog to track executions of the stored procedure and error information */
        EXECUTE DBA.InsertActivityLog @currenttimestamp, @currentuser,
            @procedurename, @sqlstr, @ErrorMessage
 
    /*Raise an error: msg_str parameter of RAISERROR will contain the original error information.*/
        RAISERROR 
        (
        @ErrorMessage, 
        @ErrorSeverity, 
        1,               
        @ErrorNumber,
        @ErrorSeverity,
        @ErrorState,
        @ErrorProcedure,
        @ErrorLine
        );

    END CATCH'

    EXEC(@SQLToExecute)

	IF EXISTS(SELECT 1 FROM sys.certificates WHERE name = 'Apparatus_SigningExecutionCert')
	BEGIN
		SELECT @SQLToExecute = 'ADD SIGNATURE TO DBA.[InsertActivityLog] BY CERTIFICATE [Apparatus_SigningExecutionCert]'
		EXEC(@SQLToExecute)
	END

    SELECT  '0,ExecutionSuccessful|<Data><Instance Name="Execution"><Value Name="ExecutionComplete" UofM="">1</Value></Instance></Data>' AS StringValue

END TRY
BEGIN CATCH
			
		/*http://msdn.microsoft.com/en-us/library/ms179296%28v=SQL.105%29.aspx*/

    DECLARE @ErrorMessage NVARCHAR(4000) ,
        @ErrorNumber INT ,
        @ErrorSeverity INT ,
        @ErrorState INT ,
        @ErrorLine INT ,
        @ErrorProcedure NVARCHAR(200);

    /*Assign variables to error-handling functions that 
     capture information for RAISERROR.*/
    SELECT  @ErrorNumber = ERROR_NUMBER() ,
            @ErrorSeverity = ERROR_SEVERITY() ,
            @ErrorState = ERROR_STATE() ,
            @ErrorLine = ERROR_LINE() ,
            @ErrorProcedure = ISNULL(ERROR_PROCEDURE(), '-');

	/*Build the message string that will contain original
     error information.*/
    SELECT  @ErrorMessage = N'' + ERROR_MESSAGE();

    SELECT  '2,ExecutionFailed:' + @ErrorMessage
            + '|<Data><Instance Name="Execution"><Value Name="ExecutionComplete" UofM="">0</Value></Instance></Data>' AS StringValue

END CATCH