SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET NUMERIC_ROUNDABORT OFF
SET QUOTED_IDENTIFIER ON

SET NOCOUNT ON

BEGIN TRY
/*Make Certain we're in the Apparatus_DBA database - if we're not - ABORT!*/
    IF DB_NAME() <> 'Apparatus_DBA'
        BEGIN
            SELECT  '1,ExecutionFailed:Database Context Incorrect|<Data><Instance Name="Execution"><Value Name="ExecutionComplete" UofM="">0</Value></Instance></Data>' AS StringValue
            RETURN
        END	

    DECLARE @SQLToExecute NVARCHAR(MAX)
    DECLARE @ProcedureName NVARCHAR(250)

    SELECT  @ProcedureName = 'THISISTHEPROCEDURENAMEYOUARECREATING'
	
    IF EXISTS ( SELECT  *
                FROM    INFORMATION_SCHEMA.ROUTINES
                WHERE   SPECIFIC_SCHEMA = N'DBA'
                        AND SPECIFIC_NAME = @ProcedureName )
        BEGIN
            SELECT  @SQLToExecute = 'DROP PROCEDURE DBA.'
                    + QUOTENAME(@ProcedureName) + ';'
            EXEC(@SQLToExecute)
        END
		

    SELECT  @SQLToExecute = '/*CREATE PROCEDURE STATEMENT GOES HERE - THIS IS WHERE YOU DO YOUR WORK - DO NOT TOUCH ANYTHING ELSE, Got It!?!?!*/'
    EXEC(@SQLToExecute)

    IF EXISTS ( SELECT  1
                FROM    sys.certificates
                WHERE   name = 'Apparatus_SigningExecutionCert' )
        BEGIN
            SELECT  @SQLToExecute = 'ADD SIGNATURE TO DBA.'
                    + QUOTENAME(@ProcedureName)
                    + ' BY CERTIFICATE [Apparatus_SigningExecutionCert];'
            EXEC(@SQLToExecute)
        END

    SELECT  '0,ExecutionSuccessful|<Data><Instance Name="Execution"><Value Name="ExecutionComplete" UofM="">1</Value></Instance></Data>' AS StringValue

END TRY
BEGIN CATCH
			
		/*http://msdn.microsoft.com/en-us/library/ms179296%28v=SQL.105%29.aspx*/

    DECLARE @ErrorMessage NVARCHAR(4000) ,
        @ErrorNumber INT ,
        @ErrorSeverity INT ,
        @ErrorState INT ,
        @ErrorLine INT ,
        @ErrorProcedure NVARCHAR(200);

    /*Assign variables to error-handling functions that 
     capture information for RAISERROR.*/
    SELECT  @ErrorNumber = ERROR_NUMBER() ,
            @ErrorSeverity = ERROR_SEVERITY() ,
            @ErrorState = ERROR_STATE() ,
            @ErrorLine = ERROR_LINE() ,
            @ErrorProcedure = ISNULL(ERROR_PROCEDURE(), '-');

	/*Build the message string that will contain original
     error information.*/
    SELECT  @ErrorMessage = N'' + ERROR_MESSAGE();

    SELECT  '2,ExecutionFailed:' + @ErrorMessage
            + '|<Data><Instance Name="Execution"><Value Name="ExecutionComplete" UofM="">0</Value></Instance></Data>' AS StringValue

END CATCH