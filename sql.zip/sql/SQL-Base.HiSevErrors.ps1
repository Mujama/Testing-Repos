if(!(Test-Path variable:\Instance)){[string]$Instance="DEFAULT"}

$ErrorActionPreference = "Stop"
Set-Alias AM Add-Member
Set-Alias NOB New-Object
$SP = "ScriptProperty"

function EscValue{param($V);$V.Replace('&','&amp;').Replace('<','&lt;').Replace('>','&gt;')}

function InstanceValue{param($Name,$UofM,[string]$Value)
NOB PSObject -Prop (@{'Name'=$Name;'UofM'=$UofM;'Value'=$Value.ToString()}) |
AM $SP ToXML {[string]::Format('<Value Name="{0}" UofM="{1}">{2}</Value>',$this.Name,$this.UofM,$(EscValue $this.Value))} -Pass -Force}

function Instance{param($Name,$Type,$State)
NOB PSObject -Prop (@{'Name'=$Name;'Type'=$Type;'State'=$State;'Values'=[PSObject[]]""}) |
AM ScriptMethod AddValue {param($Value)$this.Values+=$Value} -Pass |
AM $SP ToXML {[string]::Format('<Instance Name="{0}" Type="{1}" State="{2}">{3}</Instance>',$this.Name,$this.Type,$this.State,$(@(foreach($v in $this.Values){$v.ToXml}) -join ""))} -Pass}

function Out-Kore{param([int]$State,[PSObject[]]$Instances,$ShortText)
[string]::Format("{0}{2}|<Data>{1}</Data>",$State,$(@(foreach($I in $Instances){$I.ToXml}) -join ""), $(if($ShortText -ne $null){",$ShortText"}else{""}))}
try{if($Instance -eq "DEFAULT"){$SvcName="MSSQLSERVER";$IName="."}else{$SvcName=$PerfName;$IName=".\$Instance"}
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO')
$s=NOB Microsoft.SqlServer.Management.Smo.Server ("$IName")
$d=$s.ReadErrorLog()
$Es=@();$ESeek = 0;$State=0
foreach($r in $d.Rows)
{if($ESeek -eq 1){$eOb.Txt=$eOb.Txt+$r.Text;$Es+=$eOb;$ESeek=0}
elseif($r.Text -like "Error*"){$eSeek=1;$eOb=NOB PSObject -Prop (@{'Time'=$r.LogDate;'SPID'=$r.ProcessInfo;'Txt'=$r.Text})}}
$Instances = @()
foreach($E in $Es){
if($e.Time.AddMinutes(5) -ge $(Get-Date)){
$tt = $E.Txt
$Sev=$tt.Substring($tt.IndexOf('Severity:')+9, 3).Trim()
$Num=$tt.Substring($tt.IndexOf('Error:')+6, 6).Trim().Replace(',', '')
$Msg=$tt.Substring($tt.IndexOf('.')+1).Trim()
if($Sev -ge 21){$iState=2}else{$iState=1}
if($iState -gt $State){$State=$iState}
$I = Instance "Error" "SQL Error" $iState
$I.AddValue($(InstanceValue "Severity" "" $Sev))
$I.AddValue($(InstanceValue "Number" "" $Num))
$I.AddValue($(InstanceValue "Message" "" $Msg))
$I.AddValue($(InstanceValue "Time" "datetime" $E.Time))
$Instances+=$I}}
if($Instances.Count -gt 0){Out-Kore $State $Instances "Errors Found"}
else{'0,NO ERRORS FOUND|<Data><Instance Name="default" State="0"><Value UofM="" Name="State">No Errors Found</Value></Instance></Data>'}
}catch{[string]::Format('3,ERROR IN POWERSHELL|<Data><Instance Name="default"><Value UofM="" Name="Error">{0}</Value></Instance></Data>',$(EscValue "$($_.Exception);$($_.InvocationInfo.ScriptLineNumber))"));throw}
