/*######################################
SQL-Base.LastBackup			
Author: Kyle Neier
Created: 20130809
Validated Versions: 2005, 2008, 2008R2, 2012
Validated Editions: Standard, Enterprise

Synopsis: Interrogates MSDB for each database 
to determine the last database backup.

Will warn if no backup (full or diff) 
has been recorded for > 7 days. 

Will Crit if nothing for > 14 days or 
no full (only diff) for > 30 days.
######################################*/

SET NOCOUNT ON
    
/*Init some variables*/
DECLARE @VersionMajor TINYINT

/*Obtain current major version of SQL*/
    	
	
CREATE TABLE #Backups
    (
     DBName SYSNAME,
     LastFullBackup DATETIME NULL,
     LastDiffBackup DATETIME NULL,
     [State] CHAR(1) NULL
    );


CREATE TABLE #LastFullBackup
    (
     database_name SYSNAME,
     BackupDate DATETIME NULL
    )

CREATE TABLE #LastDiffBackup
    (
     database_name SYSNAME,
     BackupDate DATETIME NULL
    )

INSERT  INTO #LastFullBackup
        (
         database_name,
         BackupDate
        )
        SELECT  bs.database_name,
                MAX(bs.backup_finish_date) AS BackupDate
        FROM    msdb..backupset bs
        WHERE   bs.TYPE='D'
        GROUP BY bs.database_name

INSERT  INTO #LastDiffBackup
        (
         database_name,
         BackupDate
        )
        SELECT  bs.database_name,
                MAX(bs.backup_finish_date) AS BackupDate
        FROM    msdb..backupset bs
        WHERE   bs.TYPE='I'
        GROUP BY bs.database_name


INSERT  INTO #Backups
        (
         DBName,
         LastFullBackup,
         LastDiffBackup
        )
        SELECT  db.name,
                ISNULL(LastFullBackup.BackupDate, '1/1/1900'),
                ISNULL(LastDiffBackup.BackupDate, '1/1/1900')
        FROM    sysdatabases db
                LEFT JOIN #LastFullBackup LastFullBackup ON db.Name=LastFullBackup.database_name
                LEFT JOIN #LastDiffBackup LastDiffBackup ON db.Name=LastDiffBackup.database_name
        WHERE   db.Name NOT IN ('tempdb')/*Can't backup snapshot or tempdb databases*/
                AND DATABASEPROPERTYEX(db.name, 'status')='ONLINE'
                AND HAS_DBACCESS(db.name)=1

UPDATE  #Backups
SET     State=CASE WHEN DATEDIFF(dd, LastFullBackup, GETDATE())>30
                        OR (
                            DATEDIFF(dd, LastFullBackup, GETDATE())>14
                            AND DATEDIFF(dd, LastDiffBackup, GETDATE())>14
                           ) THEN 2
                   WHEN DATEDIFF(dd, LastFullBackup, GETDATE())>7
                        AND DATEDIFF(dd, LastDiffBackup, GETDATE())>7 THEN 1
                   ELSE 0
              END




/*Init some more local variables*/
DECLARE @WarningCount INT,
    @CriticalCount INT,
    @ShortMessage VARCHAR(255),
    @State CHAR(1)

/*Store the count of occurences*/
SELECT  @WarningCount=COUNT(DISTINCT DBName)
FROM    #Backups
WHERE   [State]=1


SELECT  @CriticalCount=COUNT(DISTINCT DBName)
FROM    #Backups
WHERE   [State]=2


/*Materialize the state and short message*/
IF @WarningCount=0
    AND @CriticalCount=0
    SELECT  @State=0,
            @ShortMessage='ALL DATABASES BACKED UP'
ELSE
    IF @CriticalCount>0
        SELECT  @State=2,
                @ShortMessage=CAST(@CriticalCount AS VARCHAR(5))+' DATABASES HAVE CRITICAL BACKUP STATE, '+CAST(@WarningCount AS VARCHAR(5))
                +' DATABASES HAVE WARNING BACKUP STATE'
    ELSE
        SELECT  @State=1,
                @ShortMessage=CAST(@WarningCount AS VARCHAR(5))+' DATABASES HAVE WARNING BACKUP STATE'

/*Put code from Jeffers here*/





DROP TABLE #Backups
DROP TABLE #LastFullBackup
DROP TABLE #LastDiffBackup
