/*######################################
SQL.VLFCount			
Author: Kyle Neier
Created: 20130808
Validated Versions: 2005, 2008, 2008R2, 2012
Validated Editions: Standard, Enterprise

Synopsis: Interrogates each database 
for the VLF count of the log file(s)

Will Warn when VLF >= 500, Crit when 
VLF >= 2000
######################################*/
SET NOCOUNT ON
BEGIN TRY

/*Counts Out of Spec*/
    DECLARE @WarningVLFCount INT,
        @CriticalVLFCount INT

    SELECT  @WarningVLFCount=500,
            @CriticalVLFCount=2000

    SET NOCOUNT ON

    CREATE TABLE #DBInfo_VLF
        (
         RecoveryUnitId INT NULL,
         FileID INT,
         FileSize BIGINT,
         StartOffset BIGINT,
         FSeqNo INT,
         Status TINYINT,
         Parity BIGINT,
         CreateLSN VARCHAR(8000),
         DatabaseName SYSNAME NULL
        )

/*Init some variables*/
    DECLARE @DatabaseName VARCHAR(1000),
        @SQL VARCHAR(8000),
        @VersionMajor TINYINT

/*Obtain current major version of SQL*/
    SELECT  @VersionMajor=LEFT(CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(100)), CHARINDEX('.', CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(100)))-1)

    DECLARE csrDatabases CURSOR FAST_FORWARD LOCAL
    FOR
        SELECT  name
        FROM    sys.databases
        WHERE   state_desc='ONLINE' /*can only get info for Online Databases*/
                AND source_database_id IS NULL /* if get loginfo for snapshot databases - causes nonyielding scheduler issue */

    OPEN csrDatabases

    FETCH NEXT FROM csrDatabases INTO @DatabaseName

/*Only if the instance is SQL 2005 or higher*/
    IF @VersionMajor>=9 
        BEGIN
            WHILE @@FETCH_STATUS=0 
                BEGIN

                    SET @SQL='DBCC LOGINFO('+CHAR(39)+@DatabaseName+CHAR(39)+')'

                    IF @VersionMajor>=11 /*SQL 2012 Added a column to LOGINFO*/ 
                        BEGIN
                            INSERT  INTO #DBInfo_VLF
                                    (
                                     RecoveryUnitId,
                                     FileID,
                                     FileSize,
                                     StartOffset,
                                     FSeqNo,
                                     Status,
                                     Parity,
                                     CreateLSN
					                )
                                    EXEC (
                                          @SQL
                                        )
                        END
                    ELSE 
                        BEGIN
                            INSERT  INTO #DBInfo_VLF
                                    (
                                     FileID,
                                     FileSize,
                                     StartOffset,
                                     FSeqNo,
                                     Status,
                                     Parity,
                                     CreateLSN
                                    )
                                    EXEC (
                                          @SQL
                                        )
                        END
                    UPDATE  #DBInfo_VLF
                    SET     DatabaseName=@DatabaseName
                    WHERE   DatabaseName IS NULL

                    FETCH NEXT FROM csrDatabases INTO @DatabaseName

                END

            CLOSE csrDatabases
            DEALLOCATE csrDatabases

        END

/*create table */
    CREATE TABLE #VLFCount
        (
         DBName SYSNAME,
         VLFCount INT,
         [State] INT NULL
        )

    INSERT  INTO #VLFCount
            (
             DBName,
             VLFCount,
             [State]
            )
            SELECT  DatabaseName,
                    COUNT(DatabaseName),
                    CASE WHEN COUNT(DatabaseName)<@WarningVLFCount THEN 0
                         WHEN COUNT(DatabaseName)>@CriticalVLFCount THEN 2
                         ELSE 1
                    END
            FROM    #DBInfo_VLF
            GROUP BY DatabaseName


/*Build out the XML for the data portion*/
    DECLARE @x XML 
    SET @x=(SELECT  (SELECT db.Name AS [Instance/@Name],
                            'SQL Database' AS [Instance/@Type],
                            ISNULL(VLF.[State], 1) AS [Instance/@State],
                            'VLFCount' AS [Instance/Value/@Name],
                            '' AS [Instance/Value/@UofM],
                            ISNULL(VLF.VLFCount, 0) AS [Instance/Value]
                     FROM   sys.databases db
                            LEFT JOIN #VLFCount VLF ON db.Name=VLF.DBName
                    FOR
                     XML PATH(''),
                         TYPE)
        FOR XML PATH('Data'),
                TYPE)


/*Init some more local variables*/
    DECLARE @WarningCount INT,
        @CriticalCount INT,
        @ShortMessage VARCHAR(255),
        @State CHAR(1)

/*Store the count of occurences*/
    SELECT  @WarningCount=COUNT(DISTINCT DBName)
    FROM    #VLFCount
    WHERE   [State]=1

    SELECT  @CriticalCount=COUNT(DISTINCT DBName)
    FROM    #VLFCount
    WHERE   [State]=2

/*Materialize the state and short message*/
    IF @WarningCount=0
        AND @CriticalCount=0 
        SELECT  @State=0,
                @ShortMessage='NO DATABASES WITH TOO MANY VLFs'
    ELSE 
        IF @CriticalCount>0 
            SELECT  @State=2,
                    @ShortMessage=CAST(@CriticalCount AS VARCHAR(5))+' DATABASES WITH CRITICAL VLF COUNT, '+CAST(@WarningCount AS VARCHAR(5))
                    +' DATABASES WITH WARNING VLF COUNT'
        ELSE 
            SELECT  @State=1,
                    @ShortMessage=CAST(@WarningCount AS VARCHAR(5))+' DATABASES WITH WARNING VLF COUNT'


/*Return the State, Message, and XML*/
    SELECT  @State+','+@ShortMessage+'|'+CAST(@x AS VARCHAR(MAX)) AS StringValue


/*Clean Up*/
    DROP TABLE #VLFCount
    DROP TABLE #DBInfo_VLF
END TRY
BEGIN CATCH
			
		/*http://msdn.microsoft.com/en-us/library/ms179296%28v=SQL.105%29.aspx*/

    DECLARE @ErrorMessage NVARCHAR(4000),
        @ErrorNumber INT,
        @ErrorSeverity INT,
        @ErrorState INT,
        @ErrorLine INT,
        @ErrorProcedure NVARCHAR(200);

    /*Assign variables to error-handling functions that 
     capture information for RAISERROR.*/
    SELECT  @ErrorNumber=ERROR_NUMBER(),
            @ErrorSeverity=ERROR_SEVERITY(),
            @ErrorState=ERROR_STATE(),
            @ErrorLine=ERROR_LINE(),
            @ErrorProcedure=ISNULL(ERROR_PROCEDURE(), '-');

	/*Build the message string that will contain original
     error information.*/
    SELECT  @ErrorMessage=N'Error %d, Level %d, State %d, Procedure %s, Line %d, '+'Message: '+ERROR_MESSAGE();

    SELECT  '3|<Data><Instance Name="default" Type="SQL"><Value Name="Error" UofM="">'+REPLACE(REPLACE(REPLACE(REPLACE(@ErrorMessage, '&', '&amp;'), '<', '&lt;'),
                                                                                                       '>', '&gt;'),
                                                                                               'Error %d, Level %d, State %d, Procedure %s, Line %d, Message: ',
                                                                                               '')+'</Value></Instance></Data>' AS StringValue

    

    /*Raise an error: msg_str parameter of RAISERROR will contain
     the original error information.*/
    RAISERROR 
        (
        @ErrorMessage, 
        @ErrorSeverity, 
        1,               
        @ErrorNumber,    /* parameter: original error number.*/
        @ErrorSeverity,  /* parameter: original error severity.*/
        @ErrorState,     /* parameter: original error state.*/
        @ErrorProcedure, /* parameter: original error procedure name.*/
        @ErrorLine       /* parameter: original error line number.*/
        );

END CATCH      

