if(!(Test-Path variable:\Warn)){[double]$Warn=0}
if(!(Test-Path variable:\Crit)){[double]$Crit=0}
if(!(Test-Path variable:\Instance)){[string]$Instance="DEFAULT"}

$ErrorActionPreference = "Stop"
Set-Alias AM Add-Member
Set-Alias NOB New-Object
$SP = "ScriptProperty"
function InstanceValue		
{param($Name,$UofM,[string]$Value,$Warning,$Critical)
NOB PSObject -Prop (@{'Name'=$Name;'UofM'=$UofM;'Value'=$Value.ToString();'Warning'=$Warning;'Critical'=$Critical}) |
AM $SP EscapeValue {$this.Value.Replace('&', '&amp;').Replace('<', '&lt;').Replace('>', '&gt;')} -PassThru |
AM $SP ToXML {[string]::Format('<Value Name="{0}" UofM="{1}" Warning="{2}" Critical="{3}">{4}</Value>',$this.Name,$this.UofM,$this.Warning,$this.Critical,$this.EscapeValue)} -PassThru -Force
}

function Instance
{param($Name,$Type,$State)
NOB PSObject -Property (@{'Name'=$Name;'Type'=$Type;'State'=$State;'Values'=[PSObject[]]""}) |
AM ScriptMethod AddValue {param($Value)$this.Values+=$Value} -PassThru |
AM $SP ToXML {[string]::Format('<Instance Name="{0}" Type="{1}" State="{2}">{3}</Instance>',$this.Name,$this.Type,$this.State,$(@(foreach($v in $this.Values){$v.ToXml}) -join ""))} -PassThru
}

function Out-Kore
{param([int]$State,[PSObject[]]$Instances)
[string]::Format("{0}|<Data>{1}</Data>",$State,$(@(foreach($I in $Instances){$I.ToXml}) -join ""))
}

function Get-State{
param([double]$Value,[double]$Warn,[double]$Crit)
	<#	3 states: 1 < Warn > 2 < Crit > 3#>
	if($Warn -gt $Crit)
	{if($Value -lt $Crit){2}
	elseif($Value -gt $Warn) {0}
	else{1}
	}else
	{if($Value -ge $Crit){2}
	elseif($Value -lt $Warn){0}
	else{1}}
}

try{
$Vols = gwmi Win32_Volume -F "DriveType = 3" | ?{$_.Label -ne "System Reserved" -and $_.SystemVolume -eq $false -and (gwmi win32_logicaldisk|%{"$($_.DeviceID)\"}) -notcontains $_.Caption -and (gwmi win32_logicaldisk|%{"$($_.VolumeName)"}) -notcontains $_.Label}
$Instances = @()
if($Warn -eq 0){$Warn=85}
if($Crit -eq 0){$Crit=90}
$State=0
if($Vols -ne $null)
{
foreach($Vol in $Vols)
{[double]$size = $Vol.Capacity
[double]$freespace = $Vol.FreeSpace
$pctused = 100-[Math]::Round(($freespace/$size)*100,2)
$iState = Get-State $pctused $Warn $Crit
if($iState -gt $State){$State=$iState}
$I = Instance $Vol.Name "MountPoint" $iState
$I.AddValue((InstanceValue "Capacity" "b" $size.ToString()))
$I.AddValue((InstanceValue "FreeSpace" "b" $freespace.ToString()))
$I.AddValue((InstanceValue "PercUsed" "%" $pctused.ToString() $Warn $Crit))
$Instances += $I}
}		
Out-Kore $State $Instances
}catch{[string]::Format('3|<Data><Instance Name="default"><Value UofM="" Name="Error">{0}</Value></Instance></Data>',$("$($_.Exception);$($_.InvocationInfo.ScriptLineNumber))".Replace('&', '&amp;').Replace('<', '&lt;').Replace('>', '&gt;')));throw}
