SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET NUMERIC_ROUNDABORT OFF
SET QUOTED_IDENTIFIER ON

SET NOCOUNT ON

BEGIN TRY
/*Make Certain we're in the Apparatus_DBA database - if we're not - ABORT!*/
    IF DB_NAME() <> 'Apparatus_DBA'
        BEGIN
            SELECT  '1,ExecutionFailed:Database Context Incorrect|<Data><Instance Name="Execution"><Value Name="ExecutionComplete" UofM="">0</Value></Instance></Data>' AS StringValue
            RETURN
        END	

    DECLARE @SQLToExecute NVARCHAR(MAX)
	
    IF NOT EXISTS ( SELECT  1
                    FROM    sys.tables t
                            JOIN sys.schemas s ON t.schema_id = s.schema_id
                    WHERE   s.name = 'DBA'
                            AND t.Name = 'ActivityLog' )
        BEGIN

            SELECT  @SQLToExecute = 'CREATE TABLE DBA.ActivityLog
            (
              ExecutionTime DATETIME NOT NULL ,
              LoginName SYSNAME NOT NULL ,
              ProcedureExecuted SYSNAME NOT NULL ,
              DynamicSQL VARCHAR(2000) NULL ,
              ErrorMsg NVARCHAR(4000) NULL
            )'

            EXEC(@SQLToExecute)
		
            SELECT  @SQLToExecute = 'CREATE UNIQUE CLUSTERED INDEX [IX_ExecTimeLogin] ON [DBA].[ActivityLog]
        (
        [ExecutionTime] ASC,
        [LoginName] ASC
        )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)'

            EXEC(@SQLToExecute)
        END

    SELECT  '0,ExecutionSuccessful|<Data><Instance Name="Execution"><Value Name="ExecutionComplete" UofM="">1</Value></Instance></Data>' AS StringValue

END TRY
BEGIN CATCH
			
		/*http://msdn.microsoft.com/en-us/library/ms179296%28v=SQL.105%29.aspx*/

    DECLARE @ErrorMessage NVARCHAR(4000) ,
        @ErrorNumber INT ,
        @ErrorSeverity INT ,
        @ErrorState INT ,
        @ErrorLine INT ,
        @ErrorProcedure NVARCHAR(200);

    /*Assign variables to error-handling functions that 
     capture information for RAISERROR.*/
    SELECT  @ErrorNumber = ERROR_NUMBER() ,
            @ErrorSeverity = ERROR_SEVERITY() ,
            @ErrorState = ERROR_STATE() ,
            @ErrorLine = ERROR_LINE() ,
            @ErrorProcedure = ISNULL(ERROR_PROCEDURE(), '-');

	/*Build the message string that will contain original
     error information.*/
    SELECT  @ErrorMessage = N'' + ERROR_MESSAGE();

    SELECT  '2,ExecutionFailed:' + @ErrorMessage
            + '|<Data><Instance Name="Execution"><Value Name="ExecutionComplete" UofM="">0</Value></Instance></Data>' AS StringValue

END CATCH