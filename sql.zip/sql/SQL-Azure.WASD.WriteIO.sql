DECLARE @Warning INT = 95, @Critical INT = 99

SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET NUMERIC_ROUNDABORT OFF
SET QUOTED_IDENTIFIER ON

SET NOCOUNT ON
BEGIN TRY

DECLARE @x XML, @State CHAR(1) = '3'


    CREATE TABLE #Instance
        (
          InstanceID INT IDENTITY(1, 1)
                         NOT NULL ,
          InstanceName NVARCHAR(1000) NOT NULL ,
          InstanceType NVARCHAR(100) NULL ,
          InstanceState NVARCHAR(100) NULL ,
          InstanceStatus NVARCHAR(100) NULL
        )
    CREATE TABLE #Value
        (
          ValueID INT IDENTITY(1, 1)
                      NOT NULL ,
          InstanceID INT NOT NULL ,
          ValueName NVARCHAR(1000) NOT NULL ,
          ValueUofM NVARCHAR(100) NOT NULL ,
          [Value] NVARCHAR(1000) NOT NULL ,
          ValueCritical NVARCHAR(100) NULL ,
          ValueWarning NVARCHAR(100) NULL
        );

		DECLARE @MetricValue NUMERIC(18,2);

SELECT @MetricValue = MAX(avg_log_write_percent)
FROM sys.dm_db_resource_stats
WHERE end_time >= DATEADD(ss, -300, GETDATE())


SELECT @State = CASE WHEN @MetricValue > @Critical THEN 2 WHEN @MetricValue > @Warning THEN 1 WHEN @MetricValue <= @Warning THEN 0 ELSE 3 END


    INSERT  INTO #Instance
            ( InstanceName ,
              InstanceType ,
              InstanceState ,
              InstanceStatus
            )
    VALUES  ( 'AzureDB_WriteIO' ,
              'PerformanceMetric' ,
              @State ,
              NULL
            )

/*
Insert Values for Each Instance Here
INSERT INTO #Value (InstanceID, ValueName, ValueUofM, [Value], ValueCritical, ValueWarning)
*/
    INSERT  INTO #Value
            ( InstanceID ,
              ValueName ,
              ValueUofM ,
              [Value] ,
              ValueCritical ,
              ValueWarning
            )
    VALUES  ( '1' ,
              'WriteIO_Percent' ,
              '%' ,
              ISNULL(@MetricValue, 0.00) ,
              @Critical ,
              @Warning
            )

    
    SET @x = ( SELECT   ( SELECT    i.InstanceName AS [Instance/@Name] ,
                                    i.InstanceType AS [Instance/@Type] ,
                                    i.InstanceState AS [Instance/@State] ,
                                    i.InstanceStatus AS [Instance/@Status] ,
                                    ( SELECT    v.ValueName AS [Value/@Name] ,
                                                v.ValueUofM AS [Value/@UofM] ,
                                                v.ValueCritical AS [Value/@Critical] ,
                                                v.ValueWarning AS [Value/@Warning] ,
                                                v.[Value] AS [Value]
                                      FROM      #Value v
                                      WHERE     v.InstanceID = i.InstanceID
                                    FOR
                                      XML PATH('') ,
                                          TYPE
                                    ) AS [Instance]
                          FROM      #Instance i
                        FOR
                          XML PATH('') ,
                              ROOT('Data') ,
                              TYPE
                        )
             )

    SELECT  @State = MAX(InstanceState)
    FROM    #Instance


    DROP TABLE #Instance
    DROP TABLE #Value

    SELECT  ISNULL(@State, '3') + '|' + ISNULL(CAST(@x AS NVARCHAR(MAX)),
                                               N'<Data><Instance Name="Unknown"><Value Name="Unknown" UofM=""/></Instance></Data>') AS StringValue
END TRY
BEGIN CATCH
			
		/*http://msdn.microsoft.com/en-us/library/ms179296%28v=SQL.105%29.aspx*/

    DECLARE @ErrorMessage NVARCHAR(4000) ,
        @ErrorNumber INT ,
        @ErrorSeverity INT ,
        @ErrorState INT ,
        @ErrorLine INT ,
        @ErrorProcedure NVARCHAR(200);

    /*Assign variables to error-handling functions that 
     capture information for RAISERROR.*/
    SELECT  @ErrorNumber = ERROR_NUMBER() ,
            @ErrorSeverity = ERROR_SEVERITY() ,
            @ErrorState = ERROR_STATE() ,
            @ErrorLine = ERROR_LINE() ,
            @ErrorProcedure = ISNULL(ERROR_PROCEDURE(), '-');

	/*Build the message string that will contain original
     error information.*/
    SELECT  @ErrorMessage = N'Error %d, Level %d, State %d, Procedure %s, Line %d, '
            + 'Message: ' + ERROR_MESSAGE();

    SELECT  '3|<Data><Instance Name="default" Type="SQL"><Value Name="Error" UofM="">'
            + REPLACE(REPLACE(REPLACE(REPLACE(@ErrorMessage, '&', '&amp;'),
                                      '<', '&lt;'), '>', '&gt;'),
                      'Error %d, Level %d, State %d, Procedure %s, Line %d, Message: ',
                      '') + '</Value></Instance></Data>' AS StringValue

    

    /*Raise an error: msg_str parameter of RAISERROR will contain
     the original error information.*/
    RAISERROR 
        (
        @ErrorMessage, 
        @ErrorSeverity, 
        1,               
        @ErrorNumber,    /* parameter: original error number.*/
        @ErrorSeverity,  /* parameter: original error severity.*/
        @ErrorState,     /* parameter: original error state.*/
        @ErrorProcedure, /* parameter: original error procedure name.*/
        @ErrorLine       /* parameter: original error line number.*/
        );

END CATCH      

