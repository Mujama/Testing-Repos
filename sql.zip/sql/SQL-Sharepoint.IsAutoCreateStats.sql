/*######################################
SQL-Sharepoint.IsAutoCreateStats			
Author: Kyle Neier
Created: 20130806
Validated Versions: 2005, 2008, 2008R2, 2012
Validated Editions: Standard, Enterprise

Synopsis: Interrogates instance for any databases that do
have utoCreateStats turned on (it's a Sharepoint thing)

######################################*/
SET NOCOUNT ON
BEGIN TRY


/*Init local variables*/
    DECLARE @OutOfSpecCount INT,
        @ShortMessage VARCHAR(255),
        @State CHAR(1)

/*Store the count of occurences*/
    SELECT  @OutOfSpecCount=COUNT(*)
    FROM    sys.databases
    WHERE   is_auto_update_stats_on=1
	AND database_id > 4

/*Materialize the state and short message*/
    SELECT  @State=CASE @OutOfSpecCount
                     WHEN 0 THEN '0'
                     ELSE '1'
                   END,
            @ShortMessage=CASE @OutOfSpecCount
                            WHEN 0 THEN 'NO DATABASES WITH AUTO_CREATE_STATS ENABLED'
                            ELSE 'AUTO_CREATE_STATS ENABLED ON '+CAST(@OutOfSpecCount AS VARCHAR(100))+' DATABASES'
                          END

/*Build out the XML for the data portion*/
    DECLARE @x XML
    SET @x=(SELECT  (SELECT name AS [Instance/@Name],
                            'SQL Database' AS [Instance/@Type],
                            is_auto_create_stats_on AS [Instance/@State],
                            'IsAutoCreateStatsOn' AS [Instance/Value/@Name],
                            '' AS [Instance/Value/@UofM],
                            is_auto_create_stats_on AS [Instance/Value]
                     FROM   sys.databases
					 WHERE database_id > 4
                    FOR
                     XML PATH(''),
                         TYPE)
        FOR XML PATH('Data'),
                TYPE)

/*Return the State, Message, and XML*/
    SELECT  @State+','+@ShortMessage+'|'+CAST(@x AS VARCHAR(MAX)) AS StringValue

END TRY
BEGIN CATCH
			
		/*http://msdn.microsoft.com/en-us/library/ms179296%28v=SQL.105%29.aspx*/

    DECLARE @ErrorMessage NVARCHAR(4000),
        @ErrorNumber INT,
        @ErrorSeverity INT,
        @ErrorState INT,
        @ErrorLine INT,
        @ErrorProcedure NVARCHAR(200);

    /*Assign variables to error-handling functions that 
     capture information for RAISERROR.*/
    SELECT  @ErrorNumber=ERROR_NUMBER(),
            @ErrorSeverity=ERROR_SEVERITY(),
            @ErrorState=ERROR_STATE(),
            @ErrorLine=ERROR_LINE(),
            @ErrorProcedure=ISNULL(ERROR_PROCEDURE(), '-');

	/*Build the message string that will contain original
     error information.*/
    SELECT  @ErrorMessage=N'Error %d, Level %d, State %d, Procedure %s, Line %d, '+'Message: '+ERROR_MESSAGE();

    SELECT  '3|<Data><Instance Name="default" Type="SQL"><Value Name="Error" UofM="">'+REPLACE(REPLACE(REPLACE(REPLACE(@ErrorMessage, '&', '&amp;'), '<', '&lt;'),
                                                                                                       '>', '&gt;'),
                                                                                               'Error %d, Level %d, State %d, Procedure %s, Line %d, Message: ',
                                                                                               '')+'</Value></Instance></Data>' AS StringValue

    

    /*Raise an error: msg_str parameter of RAISERROR will contain
     the original error information.*/
    RAISERROR 
        (
        @ErrorMessage, 
        @ErrorSeverity, 
        1,               
        @ErrorNumber,    /* parameter: original error number.*/
        @ErrorSeverity,  /* parameter: original error severity.*/
        @ErrorState,     /* parameter: original error state.*/
        @ErrorProcedure, /* parameter: original error procedure name.*/
        @ErrorLine       /* parameter: original error line number.*/
        );

END CATCH      


