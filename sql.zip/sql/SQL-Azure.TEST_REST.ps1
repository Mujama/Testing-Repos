﻿$AzureAccount = 'onkore@ircostlive.onmicrosoft.com'
$AzurePassword = 'EeY^I96$V#'

$ResourceGroup = 'prod-orca'
$ServerName = 'engage-useast'
$DatabaseName = 'Orca'

<#$ResourceGroup = 'Default-SQL-EastUS'
$ServerName = 'evalidation-useast'
$DatabaseName = 'evalidation'
#>

$CloudServiceName = "prod-auth-useast"

# Set Azure subscription ID
$AzureSecret = ConvertTo-SecureString $AzurePassword -AsPlainText -Force
$AzureCred = New-Object System.Management.Automation.PSCredential($AzureAccount, $AzureSecret)
$AzureRMAcct = Login-AzureRmAccount -Credential $AzureCred
$subscriptionId = (Get-AzureSubscription -Current).SubscriptionId

# Load ADAL Assemblies
$adal = "${env:ProgramFiles(x86)}\Microsoft SDKs\Azure\PowerShell\ServiceManagement\Azure\Services\Microsoft.IdentityModel.Clients.ActiveDirectory.dll"
$adalforms = "${env:ProgramFiles(x86)}\Microsoft SDKs\Azure\PowerShell\ServiceManagement\Azure\Services\Microsoft.IdentityModel.Clients.ActiveDirectory.WindowsForms.dll"
[System.Reflection.Assembly]::LoadFrom($adal) | Out-Null
[System.Reflection.Assembly]::LoadFrom($adalforms) |  Out-Null

$Tenant = ($AzureAccount -split "@")[1]
$AuthContext = New-Object Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext("https://login.windows.net/$Tenant")
$AuthCred = New-Object Microsoft.IdentityModel.Clients.ActiveDirectory.UserCredential($AzureAccount, $AzureSecret)
$AuthToken = $AuthContext.AcquireToken("https://management.core.windows.net/", "1950a258-227b-4e31-a9cf-717495945fc2", $AuthCred)

$RequestHeader = @{
"Authorization" = $AuthToken.CreateAuthorizationHeader();
"ContentType"= 'application/json';
"x-ms-version" = '2015-04-01'
}

#works
#$RequestURI = "https://management.azure.com/subscriptions/$SubscriptionID/resourceGroups/$ResourceGroup/providers/Microsoft.Sql/servers/$ServerName/firewallRules?api-version=2014-04-01-preview"
#$RequestURI = "https://management.core.windows.net/$SubscriptionID/services/hostedservices/$($CloudServiceName)?embed-detail=true"
#does not work
#$RequestURI = "https://management.azure.com/subscriptions/$SubscriptionID/resourceGroups/$ResourceGroup/providers/Microsoft.Sql/servers/$ServerName/databases/$DatabaseName/metrics?api-version=2014-04-01-preview&$filter=name.value eq 'cpu_percent' and timeGrain eq duration'PT5M' and startTime eq 2016-01-20T16:00:00.0000000Z and endTime eq 2016-01-20T16:45:00.0000000Z"
$RequestURI = "https://management.azure.com/subscriptions/$SubscriptionID/resourceGroups/$ResourceGroup/providers/Microsoft.Sql/servers/$ServerName/databases/$DatabaseName/metrics?api-version=2014-04-01-preview"

$me = ""
try{$response = Invoke-RestMethod -Headers $RequestHeader -Uri $RequestURI -Method Get}
catch{$_}

<#
$status = ($response.HostedService.Deployments.Deployment | ?{$_.DeploymentSlot -eq 'Production'}).Status
if($status -ne "Running1")
{$State = 2}
else{$State = 0}

$OutXML = '{1},{0}: Status: {2}|<Data>
	<Instance Name="{0}" Type="CloudService" State="{1}">
		<Value UofM="" Name="Status">{2}</Value>
	</Instance>
</Data>'

[string]::Format($OutXML, $CloudServiceName, $State, $Status)
#>



#cls
#$me | select *

