/*######################################
SQL-Base.MinMemory			
Author: Kyle Neier
Created: 20130808
Validated Versions: 2005, 2008, 2008R2, 2012
Validated Editions: Standard, Enterprise

Synopsis: Interrogates instance for current
min memory setting and validates = 0.

######################################*/
SET NOCOUNT ON
BEGIN TRY
    DECLARE @VersionMajor TINYINT,
        @State CHAR(1),
        @ShortMessage VARCHAR(255),
        @MinMemory NUMERIC(19, 2)

/*Obtain current major version of SQL*/
    SELECT  @VersionMajor=LEFT(CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(100)), CHARINDEX('.', CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(100)))-1)

    IF @VersionMajor IN (9, 10, 11, 12) /*SQL2005-2014*/ 
        BEGIN

            SELECT  @MinMemory=CAST(value AS INT)
            FROM    sys.configurations s
            WHERE   s.name LIKE '%min server memory%'

            SELECT  @State=CASE WHEN @MinMemory=0 THEN '0'
                                ELSE '1'
                           END

            DECLARE @x XML 

            SET @x=(SELECT  (SELECT 'default' AS [Instance/@Name],
                                    'SQL MEMORY' AS [Instance/@Type],
                                    @State AS [Instance/@State],
                                    (SELECT *
                                     FROM   (SELECT 'SQL MIN MEMORY SETTING' AS [Value/@Name],
                                                    'MB' AS [Value/@UofM],
                                                    CAST(CAST(@MinMemory AS INT) AS VARCHAR(100)) AS [Value]) AS a
                                    FOR
                                     XML PATH(''),
                                         TYPE) Instance
                            FOR
                             XML PATH(''),
                                 TYPE)
                FOR XML PATH('Data'),
                        TYPE)

            IF @State='0' 
                SELECT  @ShortMessage='SQL MIN MEMORY OK'
            ELSE 
                IF @State='1' 
                    SELECT  @ShortMessage='SQL MIN MEMORY WARNING:'+CAST(CAST(@MinMemory AS INT) AS VARCHAR(100))+'MB'

            SELECT  @State+','+@ShortMessage+'|'+CAST(@x AS VARCHAR(MAX)) AS StringValue

        END
END TRY
BEGIN CATCH
			
		/*http://msdn.microsoft.com/en-us/library/ms179296%28v=SQL.105%29.aspx*/

    DECLARE @ErrorMessage NVARCHAR(4000),
        @ErrorNumber INT,
        @ErrorSeverity INT,
        @ErrorState INT,
        @ErrorLine INT,
        @ErrorProcedure NVARCHAR(200);

    /*Assign variables to error-handling functions that 
     capture information for RAISERROR.*/
    SELECT  @ErrorNumber=ERROR_NUMBER(),
            @ErrorSeverity=ERROR_SEVERITY(),
            @ErrorState=ERROR_STATE(),
            @ErrorLine=ERROR_LINE(),
            @ErrorProcedure=ISNULL(ERROR_PROCEDURE(), '-');

	/*Build the message string that will contain original
     error information.*/
    SELECT  @ErrorMessage=N'Error %d, Level %d, State %d, Procedure %s, Line %d, '+'Message: '+ERROR_MESSAGE();

    SELECT  '3|<Data><Instance Name="default" Type="SQL"><Value Name="Error" UofM="">'+REPLACE(REPLACE(REPLACE(REPLACE(@ErrorMessage, '&', '&amp;'), '<', '&lt;'),
                                                                                                       '>', '&gt;'),
                                                                                               'Error %d, Level %d, State %d, Procedure %s, Line %d, Message: ',
                                                                                               '')+'</Value></Instance></Data>' AS StringValue

    

    /*Raise an error: msg_str parameter of RAISERROR will contain
     the original error information.*/
    RAISERROR 
        (
        @ErrorMessage, 
        @ErrorSeverity, 
        1,               
        @ErrorNumber,    /* parameter: original error number.*/
        @ErrorSeverity,  /* parameter: original error severity.*/
        @ErrorState,     /* parameter: original error state.*/
        @ErrorProcedure, /* parameter: original error procedure name.*/
        @ErrorLine       /* parameter: original error line number.*/
        );

END CATCH      

