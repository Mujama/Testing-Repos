 DECLARE @WarningDays INT,
    @CriticalDays INT

 SELECT @WarningDays=7,
        @CriticalDays=30

 SET NOCOUNT ON

 CREATE TABLE #ErrorLog
    (
     ErrorLine NVARCHAR(4000),
     Continuation INT
    )
 DECLARE @rowcount INT
 DECLARE @logrecord INT

 SELECT @rowcount=1,
        @logrecord=0
 WHILE @rowcount>0
    OR @logrecord>10
    BEGIN
        INSERT  INTO #ErrorLog
                EXEC sp_readerrorlog
                    @logrecord
        SELECT  @rowcount=@@rowcount
        SELECT  @logrecord=@logrecord+1
    END

 DECLARE csrError CURSOR FAST_FORWARD LOCAL
 FOR
    SELECT  ErrorLine
    FROM    #ErrorLog
    WHERE   ErrorLine LIKE '%DBCC CHECKDB%'

 DECLARE @ErrorLine NVARCHAR(4000)
 DECLARE @DBName SYSNAME
 DECLARE @ErrorsFound INT
 DECLARE @DBStart INT
 DECLARE @DBEnd INT
 DECLARE @DBLength INT
 DECLARE @ErrorDate DATETIME

 CREATE TABLE #checkdbhistory
    (
     CheckDBDate DATETIME,
     DBName SYSNAME,
     ErrorsFound INT
    )

 OPEN csrError
 FETCH NEXT FROM csrError INTO @ErrorLine

 WHILE @@FETCH_STATUS=0
    BEGIN
	
        SELECT  @ErrorsFound=SUBSTRING(@ErrorLine, PATINDEX('%found%', @ErrorLine)+6, 1),
                @DBStart=CHARINDEX('(', @ErrorLine)+1,
                @DBEnd=CHARINDEX(')', @ErrorLine),
                @ErrorDate=CAST(LEFT(@ErrorLine, 22) AS DATETIME)

        SELECT  @DBLength=@DBEnd-@DBStart

        SELECT  @DBName=(SUBSTRING(@ErrorLine, @DBStart, @DBLength))

        INSERT  INTO #checkdbhistory
                (CheckDBDate, DBName, ErrorsFound)
        VALUES  (@ErrorDate, @DBName, @ErrorsFound)


        FETCH NEXT FROM csrError INTO @ErrorLine
    END

 CLOSE csrError
 DEALLOCATE csrError


 CREATE TABLE #Instance
    (
     InstanceID INT IDENTITY(1, 1)
                    NOT NULL,
     InstanceName NVARCHAR(1000) NOT NULL,
     InstanceType NVARCHAR(100) NULL,
     InstanceState NVARCHAR(100) NULL,
     InstanceStatus NVARCHAR(100) NULL,
     Completed BIT NULL
    )

 CREATE TABLE #Value
    (
     ValueID INT IDENTITY(1, 1)
                 NOT NULL,
     InstanceID INT NOT NULL,
     ValueName NVARCHAR(1000) NOT NULL,
     ValueUofM NVARCHAR(100) NOT NULL,
     [Value] NVARCHAR(1000) NOT NULL,
     ValueCritical NVARCHAR(100) NULL,
     ValueWarning NVARCHAR(100) NULL,
     Completed BIT NULL
    );

 INSERT INTO #Instance
        (
         InstanceName,
         InstanceType,
         InstanceState,
         InstanceStatus
        )
        SELECT  db.Name,
                'SQL Database',
                CASE WHEN DATEDIFF(dd, MAX(ISNULL(CheckDBDate, '1/1/1900')), GETDATE())<@WarningDays THEN 0
                     WHEN DATEDIFF(dd, MAX(ISNULL(CheckDBDate, '1/1/1900')), GETDATE())>@CriticalDays THEN 2
                     ELSE 1
                END,
                NULL
        FROM    sysdatabases db
                LEFT JOIN #checkdbhistory cdb ON db.name=cdb.DBName
                                                 AND 0=cdb.ErrorsFound
        GROUP BY db.Name

 INSERT INTO #Value
        (
         InstanceID,
         ValueName,
         ValueUofM,
         [Value],
         ValueCritical,
         ValueWarning
        )
        SELECT  i.InstanceID,
                'LastSuccessfulIntegrityCheck',
                'datetime',
                ISNULL(MAX(CheckDBDate), '1/1/1900'),
                NULL,
                NULL
        FROM    #Instance i
                LEFT JOIN #checkdbhistory cdb ON i.InstanceName=cdb.DBName
        GROUP BY i.InstanceID

 Create Table #output(
	jsonOut ntext
)

INSERT INTO #output VALUES (cast('{"Instances":[' as ntext))

DECLARE @temp varchar(4000)

DECLARE @ptrval VARBINARY(16);
SELECT @ptrval = TEXTPTR(jsonOut) From #output

DECLARE @len int;

SELECT @len = DATALENGTH(jsonOut) / 2 FROM #output
UPDATETEXT #output.jsonOut @ptrVal @len 0 @temp


UPDATE #Instance SET Completed = 0
UPDATE #Value SET Completed = 0


WHILE exists (SELECT * from #instance i WHERE i.Completed = 0)
begin

	DECLARE @IID int
	DECLARE @INAME nvarchar(1000)
	DECLARE @ITYPE nvarchar(100)
	DECLARE @ISTATE nvarchar(100)

	SELECT TOP 1 @IID = i.InstanceID, @INAME = i.InstanceName, @ITYPE = i.InstanceType, @ISTATE = i.InstanceState FROM #instance i WHERE i.Completed = 0
	UPDATE #Instance SET completed = 1 WHERE @IID = InstanceID

	SELECT @temp = '{"Name":"' + @INAME + '","State":"' + @IState + '","Type":"' + @ITYPE + '","Values":['

SELECT @len = DATALENGTH(jsonOut) / 2 FROM #output
UPDATETEXT #output.jsonOut @ptrVal @len 0 @temp


	WHILE exists (SELECT * from #Value v where v.InstanceID = @IID and v.Completed = 0)
	begin
		DECLARE @VID int
		DECLARE @VNAME nvarchar(1000)
		DECLARE @VUOM nvarchar(100)
		DECLARE @Value nvarchar(1000)
		DECLARE @VCrit nvarchar(100)
		DECLARE @VWarn nvarchar(100)

		SELECT TOP 1 @VID = v.ValueID, @VNAME = v.ValueName, @VUOM = v.ValueUofM, @Value = v.Value, @VCrit = v.ValueCritical, @VWarn = v.ValueWarning FROM #Value v WHERE v.Completed = 0 and v.InstanceID = @IID
		UPDATE #Value SET completed = 1 WHERE @VID = ValueID

		SET @temp =  + '{"Name":"' + ISNULL(@VNAME, '') + '","UofM":"' + ISNULL(@VUOM, '') + '","Value":"' + ISNULL(@Value, '')

		SELECT @len = DATALENGTH(jsonOut) / 2 FROM #output
		UPDATETEXT #output.jsonOut @ptrVal @len 0 @temp

		if @VCrit IS NOT NULL
		begin
			SET @temp =  + '","Critical":"' + @VCrit
			SELECT @len = DATALENGTH(jsonOut) / 2 FROM #output
			UPDATETEXT #output.jsonOut @ptrVal @len 0 @temp

		end

		if @VWarn IS NOT NULL
		begin
			SET @temp =  + '","Warning":"' + @VCrit
			SELECT @len = DATALENGTH(jsonOut) / 2 FROM #output
			UPDATETEXT #output.jsonOut @ptrVal @len 0 @temp

		end
		
		SET @temp =  + '"}'
		SELECT @len = DATALENGTH(jsonOut) / 2 FROM #output
		UPDATETEXT #output.jsonOut @ptrVal @len 0 @temp


		if exists (SELECT * from #Value v where v.InstanceID = @IID and v.Completed = 0)
		begin
			SET @temp =  + ','
			SELECT @len = DATALENGTH(jsonOut) / 2 FROM #output
			UPDATETEXT #output.jsonOut @ptrVal @len 0 @temp

		end
	end

	SET @temp =  + ']}'
	SELECT @len = DATALENGTH(jsonOut) / 2 FROM #output
	UPDATETEXT #output.jsonOut @ptrVal @len 0 @temp


	if exists (SELECT * from #instance i where i.Completed = 0)
	begin
		SET @temp =  + ','
		SELECT @len = DATALENGTH(jsonOut) / 2 FROM #output
		UPDATETEXT #output.jsonOut @ptrVal @len 0 @temp

	end
end

SET @temp =  + ']}'
SELECT @len = DATALENGTH(jsonOut) / 2 FROM #output
UPDATETEXT #output.jsonOut @ptrVal @len 0 @temp

/*Init some more local variables*/
 DECLARE @WarningCount INT,
    @CriticalCount INT,
    @ShortMessage VARCHAR(255),
    @State CHAR(1)

/*Store the count of occurences*/
 SELECT @WarningCount=COUNT(DISTINCT [InstanceName])
 FROM   #Instance
 WHERE  [InstanceState]=1

 SELECT @CriticalCount=COUNT(DISTINCT [InstanceName])
 FROM   #Instance
 WHERE  [InstanceState]=2



/*Materialize the state and short message*/
 IF @WarningCount=0
    AND @CriticalCount=0
    SELECT  @State=0,
            @ShortMessage='NO DATABASES WITH INVALID CHECKDB'
 ELSE
    IF @CriticalCount>0
        SELECT  @State=2,
                @ShortMessage=CAST(@CriticalCount AS VARCHAR(5))+' DATABASES CRITICAL CHECKDB AGE, '+CAST(@WarningCount AS VARCHAR(5))+' DATABASES IN WARNING'
    ELSE
        SELECT  @State=1,
                @ShortMessage=CAST(@WarningCount AS VARCHAR(5))+' DATABASES WARNING CHECKDB AGE'


/*Return the State, Message, and XML*/
SELECT @temp = @State+','+@ShortMessage+' | '

UPDATETEXT #output.jsonOut @ptrVal 0 0 @temp


SELECT jsonOut as StringValue FROM #output


 DROP TABLE #ErrorLog
 DROP TABLE #checkdbhistory
 DROP TABLE #Instance
 DROP TABLE #Value
 DROP TABLE #output