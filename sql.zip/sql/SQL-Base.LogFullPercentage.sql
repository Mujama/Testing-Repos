/*######################################
SQL-Base.LogFullPercentage			
Author: Kyle Neier
Created: 20140403
Validated Versions: 2005, 2008, 2008R2, 2012
Validated Editions: Standard, Enterprise

Synopsis: Determines % full of each log file.

Will Warn when log file % goes beyond 
@WarningPercent (Default 70). Will Crit when
log file % goes beyond @CriticalPercent (Default 90)


######################################*/
/*
0.	OK - no need to notify anyone. All is as expected.
1.	WARNING - if the service is set to notify on warning, it will issue a non-urgent notification.
2.	CRITICAL - this will generate a notification. The service itself determines whether this is sent with a urgent or non-urgent status
3.	UNKNOWN - if the state cannot be determined or if there is an error. This will generate a notification with the same urgency as the critical level notifications

*/

SET NOCOUNT ON

BEGIN TRY

 DECLARE @WarningPercent INT,
        @CriticalPercent INT

    SELECT  @WarningPercent=70,
            @CriticalPercent=90

DECLARE @State CHAR(1)

CREATE TABLE #Instance
    (
     InstanceID INT IDENTITY(1, 1)
                    NOT NULL,
     InstanceName NVARCHAR(1000) NOT NULL,
     InstanceType NVARCHAR(100) NULL,
     InstanceState NVARCHAR(100) NULL,
     InstanceStatus NVARCHAR(100) NULL
    )

CREATE TABLE #Value
    (
     ValueID INT IDENTITY(1, 1)
                 NOT NULL,
     InstanceID INT NOT NULL,
     ValueName NVARCHAR(1000) NOT NULL,
     ValueUofM NVARCHAR(100) NOT NULL,
	 [Value] NVARCHAR(1000) NOT NULL,
	 ValueCritical NVARCHAR(100) NULL,
	 ValueWarning NVARCHAR(100) NULL
    )

/*

CREATE TABLE #LogUsed (DatabaseName NVARCHAR(128), cntr_value BIGINT)
INSERT INTO #LogUsed (DatabaseNAme, cntr_value)
SELECT db.NAME, cntr_value
FROM   sys.databases db
                            LEFT JOIN sys.dm_os_performance_counters os ON db.Name = OS.instance_name
					WHERE counter_name LIKE 'Percent Log Used%' AND instance_name not in ('_Total', 'mssqlsystemresource', 'tempdb', 'model')

 CASE 
							WHEN cntr_value < @WarningPercent THEN 0
							WHEN cntr_value >= @WarningPercent AND cntr_value < @CriticalPercent THEN 1
							WHEN cntr_value >= @CriticalPercent THEN 2 
							ELSE 3 END AS [Instance/@State],

*/


/*
Insert Instances into #Instance Table Here
INSERT INTO #Instance (InstanceName, InstanceType, InstanceState, InstanceStatus)
*/
INSERT INTO #Instance (InstanceName, InstanceType, InstanceState, InstanceStatus)
SELECT name, 'SQL Database', 
CASE 
							WHEN cntr_value < @WarningPercent THEN 0
							WHEN cntr_value >= @WarningPercent AND cntr_value < @CriticalPercent THEN 1
							WHEN cntr_value >= @CriticalPercent THEN 2 
							ELSE 3 END AS InstanceState, NULL
FROM sys.databases db
LEFT JOIN sys.dm_os_performance_counters os ON db.Name = OS.instance_name
					WHERE counter_name LIKE 'Percent Log Used%' AND instance_name not in ('_Total', 'mssqlsystemresource', 'tempdb', 'model')

/*
Insert Values for Each Instance Here
INSERT INTO #Value (InstanceID, ValueName, ValueUofM, [Value], ValueCritical, ValueWarning)
*/
INSERT INTO #Value (InstanceID, ValueName, ValueUofM, [Value], ValueCritical, ValueWarning)
SELECT i.InstanceID, 'PercentLogUsed', '%', os.cntr_value, NULL, NULL
FROM #Instance i JOIN sys.databases db ON db.Name = i.InstanceName
LEFT JOIN sys.dm_os_performance_counters os ON db.Name = OS.instance_name
					WHERE counter_name LIKE 'Percent Log Used%'


DECLARE @x XML 
			
            SET @x=(SELECT  (SELECT i.InstanceName AS [Instance/@Name],
                                    i.InstanceType AS [Instance/@Type],
                                    i.InstanceState AS [Instance/@State],
									i.InstanceStatus AS [Instance/@Status],
									(SELECT v.ValueName AS [Value/@Name],
									v.ValueUofM AS [Value/@UofM],
									v.ValueCritical AS [Value/@Critical],
									v.ValueWarning AS [Value/@Warning],
									v.[Value] AS [Value]
									FROM #Value v
									WHERE v.InstanceID = i.InstanceID
									FOR XML PATH(''), TYPE
									) AS [Instance]
                FROM #Instance i
				FOR XML PATH(''), ROOT('Data'),
                        TYPE))

SELECT @State = MAX(InstanceState) FROM #Instance

DROP TABLE #Instance
DROP TABLE #Value

SELECT  ISNULL(@State, '3')+'|'+ISNULL(CAST(@x AS NVARCHAR(MAX)), N'<Data><Instance Name="Unknown"><Value Name="Unknown" UofM=""/></Instance></Data>') AS StringValue


END TRY
BEGIN CATCH
			
		/*http://msdn.microsoft.com/en-us/library/ms179296%28v=SQL.105%29.aspx*/

    DECLARE @ErrorMessage NVARCHAR(4000),
        @ErrorNumber INT,
        @ErrorSeverity INT,
        @ErrorState INT,
        @ErrorLine INT,
        @ErrorProcedure NVARCHAR(200);

    /*Assign variables to error-handling functions that 
     capture information for RAISERROR.*/
    SELECT  @ErrorNumber=ERROR_NUMBER(),
            @ErrorSeverity=ERROR_SEVERITY(),
            @ErrorState=ERROR_STATE(),
            @ErrorLine=ERROR_LINE(),
            @ErrorProcedure=ISNULL(ERROR_PROCEDURE(), '-');

	/*Build the message string that will contain original
     error information.*/
    SELECT  @ErrorMessage=N'Error %d, Level %d, State %d, Procedure %s, Line %d, '+'Message: '+ERROR_MESSAGE();

    SELECT  '3|<Data><Instance Name="default" Type="SQL"><Value Name="Error" UofM="">'+REPLACE(REPLACE(REPLACE(REPLACE(@ErrorMessage, '&', '&amp;'), '<', '&lt;'),
                                                                                                       '>', '&gt;'),
                                                                                               'Error %d, Level %d, State %d, Procedure %s, Line %d, Message: ',
                                                                                               '')+'</Value></Instance></Data>' AS StringValue

    

    /*Raise an error: msg_str parameter of RAISERROR will contain
     the original error information.*/
    RAISERROR 
        (
        @ErrorMessage, 
        @ErrorSeverity, 
        1,               
        @ErrorNumber,    /* parameter: original error number.*/
        @ErrorSeverity,  /* parameter: original error severity.*/
        @ErrorState,     /* parameter: original error state.*/
        @ErrorProcedure, /* parameter: original error procedure name.*/
        @ErrorLine       /* parameter: original error line number.*/
        );

END CATCH
