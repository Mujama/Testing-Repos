/*######################################
SQL-Base.LastBackup			
Author: Kyle Neier
Created: 20130809
Validated Versions: 2005, 2008, 2008R2, 2012
Validated Editions: Standard, Enterprise

Synopsis: Interrogates MSDB for each database 
to determine the last database backup.

Will warn if no backup (full or diff) 
has been recorded for > 7 days. 

Will Crit if nothing for > 14 days or 
no full (only diff) for > 30 days.

Updated: 20160506 - FBG
Added logic to exclude databases that are part of a 
readable secondary
######################################*/

SET NOCOUNT ON
    
BEGIN TRY

/*Init some variables*/
    DECLARE @VersionMajor TINYINT

/*Obtain current major version of SQL*/
    SELECT  @VersionMajor=LEFT(CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(100)), CHARINDEX('.', CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(100)))-1)
    IF @VersionMajor IN (9, 10, 11, 12) /*SQL2005-2014*/ 
        BEGIN
	
	
            CREATE TABLE #Backups
                (
                 DBName SYSNAME,
                 LastFullBackup DATETIME NULL,
                 LastDiffBackup DATETIME NULL,
                 [State] CHAR(1) NULL
                );

            WITH    LastFullBackup
                      AS (SELECT    bs.database_name,
                                    MAX(bs.backup_finish_date) AS BackupDate
                          FROM      msdb..backupset bs
                          WHERE     bs.TYPE='D'
                          GROUP BY  bs.database_name),
                    LastDiffBackup
                      AS (SELECT    bs.database_name,
                                    MAX(bs.backup_finish_date) AS BackupDate
                          FROM      msdb..backupset bs
                          WHERE     bs.TYPE='I'
                          GROUP BY  bs.database_name)
                INSERT  INTO #Backups
                        (
                         DBName,
                         LastFullBackup,
                         LastDiffBackup
                        )
                        SELECT  db.name,
                                ISNULL(LastFullBackup.BackupDate, '1/1/1900'),
                                ISNULL(LastDiffBackup.BackupDate, '1/1/1900')
                        FROM    sys.databases db
                                LEFT JOIN LastFullBackup ON db.Name=LastFullBackup.database_name
                                LEFT JOIN LastDiffBackup ON db.Name=LastDiffBackup.database_name
                        WHERE   db.source_database_id IS NULL
                                AND db.Name NOT IN ('tempdb')/*Can't backup snapshot or tempdb databases*/
								AND DATABASEPROPERTYEX(db.name, 'status') = 'ONLINE'
								AND HAS_DBACCESS(db.name) = 1
								AND DB.Name NOT IN (
								SELECT DB_NAME(rs.database_id)
								FROM sys.dm_hadr_database_replica_states rs
								INNER JOIN sys.availability_replicas ar
								ON ar.group_id = rs.group_id
								AND ar.replica_id = rs.replica_id
								WHERE ar.secondary_role_allow_connections = 2)

            UPDATE  #Backups
            SET     State=CASE WHEN DATEDIFF(dd, LastFullBackup, GETDATE())>30
                                    OR (
                                        DATEDIFF(dd, LastFullBackup, GETDATE())>14
                                        AND DATEDIFF(dd, LastDiffBackup, GETDATE())>14
                                       ) THEN 2
                               WHEN DATEDIFF(dd, LastFullBackup, GETDATE())>7
                                    AND DATEDIFF(dd, LastDiffBackup, GETDATE())>7 THEN 1
                               ELSE 0
                          END


/*Build out the XML for the data portion*/
            DECLARE @x XML 
			
            SET @x=(SELECT  (SELECT db.DBName AS [Instance/@Name],
                                    'SQL Database' AS [Instance/@Type],
                                    db.State AS [Instance/@State],
                                    (SELECT *
                                     FROM   (SELECT 'LastFullBackup' AS [Value/@Name],
                                                    'datetime' AS [Value/@UofM],
                                                    CONVERT(VARCHAR(100), idb.LastFullBackup, 126) AS [Value]
                                             FROM   #Backups idb
                                             WHERE  idb.DBName=db.DBName
                                             UNION ALL
                                             SELECT 'LastDiffBackup' AS [Value/@Name],
                                                    'datetime' AS [Value/@UofM],
                                                    CONVERT(VARCHAR(100), idb.LastDiffBackup, 126) AS [Value]
                                             FROM   #Backups idb
                                             WHERE  idb.DBName=db.DBName) AS a
                                    FOR
                                     XML PATH(''),
                                         TYPE) Instance
                             FROM   #Backups db
                            FOR
                             XML PATH(''),
                                 TYPE)
                FOR XML PATH('Data'),
                        TYPE)


/*Init some more local variables*/
            DECLARE @WarningCount INT,
                @CriticalCount INT,
                @ShortMessage VARCHAR(255),
                @State CHAR(1)

/*Store the count of occurences*/
            SELECT  @WarningCount=COUNT(DISTINCT DBName)
            FROM    #Backups
            WHERE   [State]=1


            SELECT  @CriticalCount=COUNT(DISTINCT DBName)
            FROM    #Backups
            WHERE   [State]=2


/*Materialize the state and short message*/
            IF @WarningCount=0
                AND @CriticalCount=0 
                SELECT  @State=0,
                        @ShortMessage='ALL DATABASES BACKED UP'
            ELSE 
                IF @CriticalCount>0 
                    SELECT  @State=2,
                            @ShortMessage=CAST(@CriticalCount AS VARCHAR(5))+' DATABASES HAVE CRITICAL BACKUP STATE, '+CAST(@WarningCount AS VARCHAR(5))
                            +' DATABASES HAVE WARNING BACKUP STATE'
                ELSE 
                    SELECT  @State=1,
                            @ShortMessage=CAST(@WarningCount AS VARCHAR(5))+' DATABASES HAVE WARNING BACKUP STATE'


/*Return the State, Message, and XML*/
            SELECT  @State+','+@ShortMessage+'|'+CAST(@x AS VARCHAR(MAX)) AS StringValue
	    DROP TABLE #Backups
        END



END TRY
BEGIN CATCH
			
		/*http://msdn.microsoft.com/en-us/library/ms179296%28v=SQL.105%29.aspx*/

    DECLARE @ErrorMessage NVARCHAR(4000),
        @ErrorNumber INT,
        @ErrorSeverity INT,
        @ErrorState INT,
        @ErrorLine INT,
        @ErrorProcedure NVARCHAR(200);

    /*Assign variables to error-handling functions that 
     capture information for RAISERROR.*/
    SELECT  @ErrorNumber=ERROR_NUMBER(),
            @ErrorSeverity=ERROR_SEVERITY(),
            @ErrorState=ERROR_STATE(),
            @ErrorLine=ERROR_LINE(),
            @ErrorProcedure=ISNULL(ERROR_PROCEDURE(), '-');

	/*Build the message string that will contain original
     error information.*/
    SELECT  @ErrorMessage=N'Error %d, Level %d, State %d, Procedure %s, Line %d, '+'Message: '+ERROR_MESSAGE();

    SELECT  '3|<Data><Instance Name="default" Type="SQL"><Value Name="Error" UofM="">'+REPLACE(REPLACE(REPLACE(REPLACE(@ErrorMessage, '&', '&amp;'), '<', '&lt;'),
                                                                                                       '>', '&gt;'),
                                                                                               'Error %d, Level %d, State %d, Procedure %s, Line %d, Message: ',
                                                                                               '')+'</Value></Instance></Data>' AS StringValue

    

    /*Raise an error: msg_str parameter of RAISERROR will contain
     the original error information.*/
    RAISERROR 
        (
        @ErrorMessage, 
        @ErrorSeverity, 
        1,               
        @ErrorNumber,    /* parameter: original error number.*/
        @ErrorSeverity,  /* parameter: original error severity.*/
        @ErrorState,     /* parameter: original error state.*/
        @ErrorProcedure, /* parameter: original error procedure name.*/
        @ErrorLine       /* parameter: original error line number.*/
        );

END CATCH      
