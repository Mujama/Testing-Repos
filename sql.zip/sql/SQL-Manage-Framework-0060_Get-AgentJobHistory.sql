SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET NUMERIC_ROUNDABORT OFF
SET QUOTED_IDENTIFIER ON

SET NOCOUNT ON

BEGIN TRY
/*Make Certain we're in the Apparatus_DBA database - if we're not - ABORT!*/
    IF DB_NAME() <> 'Apparatus_DBA'
        BEGIN
            SELECT  '1,ExecutionFailed:Database Context Incorrect|<Data><Instance Name="Execution"><Value Name="ExecutionComplete" UofM="">0</Value></Instance></Data>' AS StringValue
            RETURN
        END	

    DECLARE @SQLToExecute NVARCHAR(MAX)
	
    IF EXISTS ( SELECT  *
                FROM    INFORMATION_SCHEMA.ROUTINES
                WHERE   SPECIFIC_SCHEMA = N'DBA'
                        AND SPECIFIC_NAME = N'Get_AgentJobHistory' )
        DROP PROCEDURE DBA.Get_AgentJobHistory

    SELECT  @SQLToExecute = 'CREATE PROCEDURE DBA.Get_AgentJobHistory
/*Parameters Go Here*/
    @job_name SYSNAME = NULL,
    @show_success VARCHAR(100) = NULL,
    @DaysBack INT = 7,
    @MaxRowsPerJob INT = 100
    WITH ENCRYPTION
AS
    BEGIN
        SET ANSI_NULLS ON
        SET ANSI_PADDING ON
        SET ANSI_WARNINGS ON
        SET ARITHABORT ON
        SET CONCAT_NULL_YIELDS_NULL ON
        SET NUMERIC_ROUNDABORT OFF
        SET QUOTED_IDENTIFIER ON

        SET NOCOUNT ON
   
        BEGIN TRY
	
	/* Declare local variables necessary for logging and error reporting */
            DECLARE @currentuser SYSNAME
            DECLARE @currenttimestamp DATETIME
            DECLARE @procedurename SYSNAME 
            DECLARE @sqlstr NVARCHAR(2000) 
            DECLARE @errormsg VARCHAR(2000)
	
	/* Initialize local variables */
            SELECT  @currentuser = ORIGINAL_LOGIN(),
                    @currenttimestamp = CURRENT_TIMESTAMP,
                    @procedurename = N''Get_AgentJobHistory'',
                    @sqlstr = ''''

				
	/* Code for procedure goes below this line */


            CREATE TABLE #JobHistory
                (
                  instance_id INT NOT NULL,
                  ExecutionStatus VARCHAR(50) NOT NULL,
                  JobName SYSNAME NOT NULL,
                  JobID UNIQUEIDENTIFIER NOT NULL,
                  ExecutionStartTime DATETIME NULL,
                  ExecutionCompletionTime DATETIME NULL,
                  SecondsExecuting INT NULL,
                  MinutesExecuting NUMERIC(18, 2) NULL,
                  HoursExecuting NUMERIC(18, 2) NULL,
                  DaysExecuting NUMERIC(18, 2) NULL,
                  StepName SYSNAME NULL,
                  StepID INT NULL,
                  ShortOutput NVARCHAR(4000) NULL
                )

            ALTER TABLE #JobHistory ADD CONSTRAINT PK_JobHistory PRIMARY KEY CLUSTERED (JobName, instance_id);

            WITH    ReturnLimiter
                      AS ( SELECT   instance_id,
                                    ROW_NUMBER() OVER ( PARTITION BY job_id ORDER BY run_date DESC ) AS RowNum
                           FROM     msdb.dbo.sysjobhistory
                         )
                INSERT  INTO #JobHistory
                        ( instance_id,
                          ExecutionStatus,
                          JobName,
                          JobID,
                          ExecutionStartTime,
                          ExecutionCompletionTime,
                          SecondsExecuting,
                          MinutesExecuting,
                          HoursExecuting,
                          DaysExecuting,
                          StepName,
                          StepID,
                          ShortOutput
                        )
                        SELECT  sjh.instance_id,
                                CASE sjh.run_status
                                  WHEN 0 THEN ''Failed''
                                  WHEN 1 THEN ''Succeeded''
                                  WHEN 2 THEN ''Retry''
                                  WHEN 3 THEN ''Canceled''
                                END AS ExecutionStatus,
                                sj.name AS JobName,
                                sj.job_id AS JobID,
                                DATEADD(ss,
                                        FLOOR(sjh.run_time / 10000) * 3600
                                        + FLOOR(sjh.run_time / 100 % 100) * 60
                                        + sjh.run_time % 100, RTRIM(run_date)) AS ExecutionStartTime,
                                DATEADD(ss,
                                        ( FLOOR(sjh.run_time / 10000) * 3600
                                          + FLOOR(sjh.run_time / 100 % 100)
                                          * 60 + sjh.run_time % 100 )
                                        + ( FLOOR(sjh.run_duration / 10000)
                                            * 3600 + FLOOR(sjh.run_duration
                                                           / 100 % 100) * 60
                                            + sjh.run_duration % 100 ),
                                        RTRIM(run_date)) AS ExecutionCompletionTime,
                                FLOOR(sjh.run_duration / 10000) * 3600
                                + FLOOR(sjh.run_duration / 100 % 100) * 60
                                + sjh.run_duration % 100 AS SecondsExecuting,
                                ( FLOOR(sjh.run_duration / 10000) * 3600
                                  + FLOOR(sjh.run_duration / 100 % 100) * 60
                                  + sjh.run_duration % 100 ) / 60.0 AS MinutesExecuting,
                                ( FLOOR(sjh.run_duration / 10000) * 3600
                                  + FLOOR(sjh.run_duration / 100 % 100) * 60
                                  + sjh.run_duration % 100 ) / 3600.0 AS HoursExecuting,
                                ( FLOOR(sjh.run_duration / 10000) * 3600
                                  + FLOOR(sjh.run_duration / 100 % 100) * 60
                                  + sjh.run_duration % 100 ) / 86400.0 AS DaysExecuting,
                                sjh.step_name StepName,
                                sjh.step_id AS StepID,
                                sjh.message ShortOutput
                        FROM    msdb.dbo.sysjobhistory sjh
                                JOIN msdb.dbo.sysjobs sj ON sj.job_id = sjh.job_id
                                JOIN ReturnLimiter ON sjh.instance_id = ReturnLimiter.instance_id
                        WHERE   ReturnLimiter.RowNum <= @MaxRowsPerJob
                                AND ( sj.name LIKE @job_name
                                      OR @job_name IS NULL
                                    )
                                AND ( @show_success IS NOT NULL
                                      OR sjh.run_status <> 1
                                    )
                                AND ( sjh.run_date >= CAST(CONVERT(VARCHAR, DATEADD(dd,
                                                              ( -1 * @DaysBack ),
                                                              GETDATE()), 112) AS INT) )
                        ORDER BY sj.name,
                                sjh.instance_id DESC;
            WITH    JobOutcome
                      AS ( SELECT   StepID,
                                    instance_id,
                                    JobName,
                                    ExecutionStartTime,
                                    ROW_NUMBER() OVER ( PARTITION BY JobName ORDER BY instance_id DESC ) AS ExecutionID,
                                    ROW_NUMBER() OVER ( PARTITION BY JobName ORDER BY instance_id DESC )
                                    + 1 AS PriorExecutionID
                           FROM     #JobHistory
                           WHERE    StepID = 0
                         ),
                    Execution
                      AS ( SELECT   cur.instance_id AS CurrentInstanceID,
                                    ISNULL(prev.instance_id, 0) AS PriorInstanceID,
                                    cur.*
                           FROM     JobOutcome cur
                                    LEFT OUTER JOIN JobOutcome prev ON cur.PriorExecutionID = prev.ExecutionID
                                                              AND cur.JobName = prev.JobName
                         )
                SELECT  jh1.JobName,
                        jh1.ExecutionStatus,
                        jh1.ExecutionStartTime,
                        jh1.ExecutionCompletionTime,
                        CAST(jh1.ShortOutput AS XML),
                        jh1.SecondsExecuting,
                        jh1.MinutesExecuting,
                        jh1.HoursExecuting,
                        x.Steps
                FROM    #JobHistory jh1
                        JOIN Execution e1 ON jh1.instance_id = e1.CurrentInstanceID
                        CROSS APPLY ( SELECT    jh.StepID AS [Step/@ID],
                                                jh.StepName AS [Step/@Name],
                                                jh.ExecutionStatus AS [Step/Result/@Status],
                                                jh.ShortOutput AS [Step/Result],
                                                jh.ExecutionStartTime AS [Step/ExecutionStats/@Start],
                                                jh.ExecutionCompletionTime AS [Step/ExecutionStats/@End],
                                                jh.SecondsExecuting AS [Step/ExecutionStats/Duration/@Seconds],
                                                jh.MinutesExecuting AS [Step/ExecutionStats/Duration/@Minutes],
                                                jh.HoursExecuting AS [Step/ExecutionStats/Duration/@Hours],
                                                jh.DaysExecuting AS [Step/ExecutionStats/Duration/@Days]
                                      FROM      Execution e
                                                JOIN #JobHistory jh ON jh.instance_id > PriorInstanceID
                                                              AND jh.instance_id < CurrentInstanceID
                                                              AND jh.JobName = e.JobName
                                                              AND jh.stepid > 0
                                      WHERE     e.CurrentInstanceID = e1.CurrentInstanceID
                                                AND jh.stepID > 0
                                      ORDER BY  jh.StepID
                                    FOR
                                      XML PATH(''''),
                                          ROOT(''Steps''),
                                          TYPE
                                    ) AS x ( Steps )
									ORDER BY jh1.ExecutionStartTime DESC
            DROP TABLE #JobHistory
       
	/* Code for procedure goes above this line */

	
	/* Execute InsertActivityLog to track executions of the stored procedure */
            EXECUTE DBA.InsertActivityLog @currenttimestamp, @currentuser,
                @procedurename, @sqlstr

        END TRY
 
        BEGIN CATCH
/* Derived from http://msdn.microsoft.com/en-us/library/ms179296%28v=SQL.105%29.aspx */
 
            DECLARE @ErrorMessage NVARCHAR(4000),
                @ErrorNumber INT,
                @ErrorSeverity INT,
                @ErrorState INT,
                @ErrorLine INT,
                @ErrorProcedure NVARCHAR(200);
 
    /* Assign variables to error-handling functions that capture information for RAISERROR. */
            SELECT  @ErrorNumber = ERROR_NUMBER(),
                    @ErrorSeverity = ERROR_SEVERITY(),
                    @ErrorState = ERROR_STATE(),
                    @ErrorLine = ERROR_LINE(),
                    @ErrorProcedure = ISNULL(ERROR_PROCEDURE(), ''-'');
 
    /*Build the message string that will contain original error information.*/
    
            SELECT  @ErrorMessage = ERROR_MESSAGE();    
	
	/* Execute InsertActivityLog to track executions of the stored procedure and error information */
            EXECUTE DBA.InsertActivityLog @currenttimestamp, @currentuser,
                @procedurename, @sqlstr, @ErrorMessage
 
            SELECT  @ErrorMessage = N''Error %d, Level %d, State %d, Procedure %s, Line %d, ''
                    + ''Message: '' + ERROR_MESSAGE();

    /*Raise an error: msg_str parameter of RAISERROR will contain the original error information.*/
            RAISERROR 
        (
        @ErrorMessage, 
        @ErrorSeverity, 
        1,               
        @ErrorNumber,
        @ErrorSeverity,
        @ErrorState,
        @ErrorProcedure,
        @ErrorLine
        );
 
        END CATCH
    END'

    EXEC(@SQLToExecute)

	IF EXISTS(SELECT 1 FROM sys.certificates WHERE name = 'Apparatus_SigningExecutionCert')
	BEGIN
		SELECT @SQLToExecute = 'ADD SIGNATURE TO DBA.[Get_AgentJobHistory] BY CERTIFICATE [Apparatus_SigningExecutionCert]'
		EXEC(@SQLToExecute)
	END

    SELECT  '0,ExecutionSuccessful|<Data><Instance Name="Execution"><Value Name="ExecutionComplete" UofM="">1</Value></Instance></Data>' AS StringValue

END TRY
BEGIN CATCH
			
		/*http://msdn.microsoft.com/en-us/library/ms179296%28v=SQL.105%29.aspx*/

    DECLARE @ErrorMessage NVARCHAR(4000) ,
        @ErrorNumber INT ,
        @ErrorSeverity INT ,
        @ErrorState INT ,
        @ErrorLine INT ,
        @ErrorProcedure NVARCHAR(200);

    /*Assign variables to error-handling functions that 
     capture information for RAISERROR.*/
    SELECT  @ErrorNumber = ERROR_NUMBER() ,
            @ErrorSeverity = ERROR_SEVERITY() ,
            @ErrorState = ERROR_STATE() ,
            @ErrorLine = ERROR_LINE() ,
            @ErrorProcedure = ISNULL(ERROR_PROCEDURE(), '-');

	/*Build the message string that will contain original
     error information.*/
    SELECT  @ErrorMessage = N'' + ERROR_MESSAGE();

    SELECT  '2,ExecutionFailed:' + @ErrorMessage
            + '|<Data><Instance Name="Execution"><Value Name="ExecutionComplete" UofM="">0</Value></Instance></Data>' AS StringValue

END CATCH