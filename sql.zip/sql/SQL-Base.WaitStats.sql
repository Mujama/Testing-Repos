/*######################################
SQL-Base.WaitStats
Author: Kyle Neier
Created: 20140409
Validated Versions: 2005, 2008, 2008R2, 2012
Validated Editions: Standard, Enterprise

Synopsis: Collects wait stats since last reset.
Will reset wait stats after collection.

At this time, it does not warn or crit for 
out of range values. However, it will warn
if the last reset was > 10 minutes ago
as we don't want to collect data that could skew 
results of analysis.

After analysis of ongoing results - 
we may add in warn or crit thresholds,
but further analysis must be done
before doing so. It just collects.



######################################*/
/*
0.	OK - no need to notify anyone. All is as expected.
1.	WARNING - if the service is set to notify on warning, it will issue a non-urgent notification.
2.	CRITICAL - this will generate a notification. The service itself determines whether this is sent with a urgent or non-urgent status
3.	UNKNOWN - if the state cannot be determined or if there is an error. This will generate a notification with the same urgency as the critical level notifications

*/

SET NOCOUNT ON

BEGIN TRY

DECLARE @State CHAR(1)
DECLARE @x XML 

CREATE TABLE #Instance
    (
     InstanceID INT IDENTITY(1, 1)
                    NOT NULL,
     InstanceName NVARCHAR(1000) NOT NULL,
     InstanceType NVARCHAR(100) NULL,
     InstanceState NVARCHAR(100) NULL,
     InstanceStatus NVARCHAR(100) NULL
    )

CREATE TABLE #Value
    (
     ValueID INT IDENTITY(1, 1)
                 NOT NULL,
     InstanceID INT NOT NULL,
     ValueName NVARCHAR(1000) NOT NULL,
     ValueUofM NVARCHAR(100) NOT NULL,
	 [Value] NVARCHAR(1000) NOT NULL,
	 ValueCritical NVARCHAR(100) NULL,
	 ValueWarning NVARCHAR(100) NULL
    )

/*Adapted from:
	 http://www.sqlskills.com/blogs/paul/wait-statistics-or-please-tell-me-where-it-hurts/ 
	 http://blogs.msdn.com/b/sqlosteam/archive/2011/11/12/when-was-sys-dm-os-wait-stats-last-cleared.aspx

*/

DECLARE @LastResetLapsedMS BIGINT,
@LastResetTime DATETIME


SELECT  @LastResetLapsedMS=wait_time_ms,
@LastResetTime = DATEADD(ss, wait_time_ms/1000*-1, GETDATE())
FROM    sys.dm_os_wait_stats
WHERE   wait_type='LAZYWRITER_SLEEP'

IF @LastResetLapsedMS<(10*60*1000) /*OR 1 = 1*/ /*last reset < 10 minutes ago - go ahead and collect stats*/
    BEGIN

        CREATE TABLE #WaitsToIgnore
            (
             WaitType NVARCHAR(60) NOT NULL
            )

        INSERT  INTO #WaitsToIgnore
                (
                 WaitType
                )
                SELECT  N'BROKER_EVENTHANDLER'
                UNION ALL
                SELECT  N'BROKER_RECEIVE_WAITFOR'
                UNION ALL
                SELECT  N'BROKER_TASK_STOP'
                UNION ALL
                SELECT  N'BROKER_TO_FLUSH'
                UNION ALL
                SELECT  N'BROKER_TRANSMITTER'
                UNION ALL
                SELECT  N'CHECKPOINT_QUEUE'
                UNION ALL
                SELECT  N'CHKPT'
                UNION ALL
                SELECT  N'CLR_AUTO_EVENT'
                UNION ALL
                SELECT  N'CLR_MANUAL_EVENT'
                UNION ALL
                SELECT  N'CLR_SEMAPHORE'
                UNION ALL
                SELECT  N'DBMIRROR_DBM_EVENT'
                UNION ALL
                SELECT  N'DBMIRROR_EVENTS_QUEUE'
                UNION ALL
                SELECT  N'DBMIRROR_WORKER_QUEUE'
                UNION ALL
                SELECT  N'DBMIRRORING_CMD'
                UNION ALL
                SELECT  N'DIRTY_PAGE_POLL'
                UNION ALL
                SELECT  N'DISPATCHER_QUEUE_SEMAPHORE'
                UNION ALL
                SELECT  N'EXECSYNC'
                UNION ALL
                SELECT  N'FSAGENT'
                UNION ALL
                SELECT  N'FT_IFTS_SCHEDULER_IDLE_WAIT'
                UNION ALL
                SELECT  N'FT_IFTSHC_MUTEX'
                UNION ALL
                SELECT  N'HADR_CLUSAPI_CALL'
                UNION ALL
                SELECT  N'HADR_FILESTREAM_IOMGR_IOCOMPLETION'
                UNION ALL
                SELECT  N'HADR_LOGCAPTURE_WAIT'
                UNION ALL
                SELECT  N'HADR_NOTIFICATION_DEQUEUE'
                UNION ALL
                SELECT  N'HADR_TIMER_TASK'
                UNION ALL
                SELECT  N'HADR_WORK_QUEUE'
                UNION ALL
                SELECT  N'KSOURCE_WAKEUP'
                UNION ALL
                SELECT  N'LAZYWRITER_SLEEP'
                UNION ALL
                SELECT  N'LOGMGR_QUEUE'
                UNION ALL
                SELECT  N'ONDEMAND_TASK_QUEUE'
                UNION ALL
                SELECT  N'PWAIT_ALL_COMPONENTS_INITIALIZED'
                UNION ALL
                SELECT  N'QDS_PERSIST_TASK_MAIN_LOOP_SLEEP'
                UNION ALL
                SELECT  N'QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP'
                UNION ALL
                SELECT  N'REQUEST_FOR_DEADLOCK_SEARCH'
                UNION ALL
                SELECT  N'RESOURCE_QUEUE'
                UNION ALL
                SELECT  N'SERVER_IDLE_CHECK'
                UNION ALL
                SELECT  N'SLEEP_BPOOL_FLUSH'
                UNION ALL
                SELECT  N'SLEEP_DBSTARTUP'
                UNION ALL
                SELECT  N'SLEEP_DCOMSTARTUP'
                UNION ALL
                SELECT  N'SLEEP_MASTERDBREADY'
                UNION ALL
                SELECT  N'SLEEP_MASTERMDREADY'
                UNION ALL
                SELECT  N'SLEEP_MASTERUPGRADED'
                UNION ALL
                SELECT  N'SLEEP_MSDBSTARTUP'
                UNION ALL
                SELECT  N'SLEEP_SYSTEMTASK'
                UNION ALL
                SELECT  N'SLEEP_TASK'
                UNION ALL
                SELECT  N'SLEEP_TEMPDBSTARTUP'
                UNION ALL
                SELECT  N'SNI_HTTP_ACCEPT'
                UNION ALL
                SELECT  N'SP_SERVER_DIAGNOSTICS_SLEEP'
                UNION ALL
                SELECT  N'SQLTRACE_BUFFER_FLUSH'
                UNION ALL
                SELECT  N'SQLTRACE_INCREMENTAL_FLUSH_SLEEP'
                UNION ALL
                SELECT  N'SQLTRACE_WAIT_ENTRIES'
                UNION ALL
                SELECT  N'WAIT_FOR_RESULTS'
                UNION ALL
                SELECT  N'WAITFOR'
                UNION ALL
                SELECT  N'WAITFOR_TASKSHUTDOWN'
                UNION ALL
                SELECT  N'WAIT_XTP_HOST_WAIT'
                UNION ALL
                SELECT  N'WAIT_XTP_OFFLINE_CKPT_NEW_LOG'
                UNION ALL
                SELECT  N'WAIT_XTP_CKPT_CLOSE'
                UNION ALL
                SELECT  N'XE_DISPATCHER_JOIN'
                UNION ALL
                SELECT  N'XE_DISPATCHER_WAIT'
                UNION ALL
                SELECT  N'XE_TIMER_EVENT'
                UNION ALL
                SELECT  N'TRACEWRITE'

        CREATE TABLE #Waits
            (
             WaitType NVARCHAR(60),
             total_wait_time_ms BIGINT,
             resource_wait_time_ms BIGINT,
             signal_wait_time_ms BIGINT,
             waiting_tasks_count BIGINT
            )

        INSERT  INTO #Waits
                (
                 WaitType,
                 total_wait_time_ms,
                 resource_wait_time_ms,
                 signal_wait_time_ms,
                 waiting_tasks_count
                )
                SELECT  [wait_type],
                        [wait_time_ms],
                        ([wait_time_ms]-[signal_wait_time_ms]) AS resource_wait_time_ms,
                        [signal_wait_time_ms],
                        [waiting_tasks_count]
                FROM    sys.dm_os_wait_stats osws
                        LEFT JOIN #WaitsToIgnore wi ON osws.wait_type=wi.WaitType
                WHERE   wi.WaitType IS NULL
                        AND osws.waiting_tasks_count>0
--ORDER BY wait_time_ms DESC
        
		DROP TABLE #WaitsToIgnore
    
		/*
	Insert Instances into #Instance Table Here
	INSERT INTO #Instance (InstanceName, InstanceType, InstanceState, InstanceStatus)
	*/
	INSERT INTO #Instance (InstanceName, InstanceType, InstanceState, InstanceStatus)
	SELECT WaitType, 'SQL WaitType', 0, NULL
	FROM #Waits

	/*
	Insert Values for Each Instance Here
	INSERT INTO #Value (InstanceID, ValueName, ValueUofM, [Value], ValueCritical, ValueWarning)
	*/
	INSERT INTO #Value (InstanceID, ValueName, ValueUofM, [Value], ValueCritical, ValueWarning)
	SELECT i.InstanceID, 'TotalWaitTime_ms', 'ms', total_wait_time_ms, NULL, NULL
	FROM #Instance i JOIN #Waits c ON i.InstanceName = c.WaitType

	INSERT INTO #Value (InstanceID, ValueName, ValueUofM, [Value], ValueCritical, ValueWarning)
	SELECT i.InstanceID, 'ResourceWaitTime_ms', 'ms', resource_wait_time_ms, NULL, NULL
	FROM #Instance i JOIN #Waits c ON i.InstanceName = c.WaitType
	
	INSERT INTO #Value (InstanceID, ValueName, ValueUofM, [Value], ValueCritical, ValueWarning)
	SELECT i.InstanceID, 'SignalWaitTime_ms', 'ms', signal_wait_time_ms, NULL, NULL
	FROM #Instance i JOIN #Waits c ON i.InstanceName = c.WaitType

	INSERT INTO #Value (InstanceID, ValueName, ValueUofM, [Value], ValueCritical, ValueWarning)
	SELECT i.InstanceID, 'WaitingTasksCount', '', resource_wait_time_ms, NULL, NULL
	FROM #Instance i JOIN #Waits c ON i.InstanceName = c.WaitType

	INSERT INTO #Value (InstanceID, ValueName, ValueUofM, [Value], ValueCritical, ValueWarning)
	SELECT i.InstanceID, 'LastResetTime', 'datetime', CONVERT(VARCHAR(100), @LastResetTime, 120), NULL, NULL
	FROM #Instance i

			
				SET @x=(SELECT  (SELECT i.InstanceName AS [Instance/@Name],
										i.InstanceType AS [Instance/@Type],
										i.InstanceState AS [Instance/@State],
										i.InstanceStatus AS [Instance/@Status],
										(SELECT v.ValueName AS [Value/@Name],
										v.ValueUofM AS [Value/@UofM],
										v.ValueCritical AS [Value/@Critical],
										v.ValueWarning AS [Value/@Warning],
										v.[Value] AS [Value]
										FROM #Value v
										WHERE v.InstanceID = i.InstanceID
										FOR XML PATH(''), TYPE
										) AS [Instance]
					FROM #Instance i
					FOR XML PATH(''), ROOT('Data'),
							TYPE))

	SELECT @State = MAX(InstanceState) FROM #Instance
	SELECT * FROM #Waits
	DROP TABLE #Waits
	
	END
	ELSE /*throw warning message up*/
	BEGIN
		SELECT @State = 1,
		@x = CAST(N'<Data><Instance Name="Unknown"><Value Name="LastResetTime" UofM=""/>'+CONVERT(VARCHAR(100), @LastResetTime, 120)+'</Instance></Data>' AS XML)
	END

/* CLEAR the wait stats for the next run */
DBCC SQLPERF ('sys.dm_os_wait_stats', CLEAR);

DROP TABLE #Instance
DROP TABLE #Value


SELECT  ISNULL(@State, '3')+'|'+ISNULL(CAST(@x AS NVARCHAR(MAX)), N'<Data><Instance Name="Unknown"><Value Name="Unknown" UofM=""/></Instance></Data>') AS StringValue

END TRY
BEGIN CATCH
			
		/*http://msdn.microsoft.com/en-us/library/ms179296%28v=SQL.105%29.aspx*/

    DECLARE @ErrorMessage NVARCHAR(4000),
        @ErrorNumber INT,
        @ErrorSeverity INT,
        @ErrorState INT,
        @ErrorLine INT,
        @ErrorProcedure NVARCHAR(200);

    /*Assign variables to error-handling functions that 
     capture information for RAISERROR.*/
    SELECT  @ErrorNumber=ERROR_NUMBER(),
            @ErrorSeverity=ERROR_SEVERITY(),
            @ErrorState=ERROR_STATE(),
            @ErrorLine=ERROR_LINE(),
            @ErrorProcedure=ISNULL(ERROR_PROCEDURE(), '-');

	/*Build the message string that will contain original
     error information.*/
    SELECT  @ErrorMessage=N'Error %d, Level %d, State %d, Procedure %s, Line %d, '+'Message: '+ERROR_MESSAGE();

    SELECT  '3|<Data><Instance Name="default" Type="SQL"><Value Name="Error" UofM="">'+REPLACE(REPLACE(REPLACE(REPLACE(@ErrorMessage, '&', '&amp;'), '<', '&lt;'),
                                                                                                       '>', '&gt;'),
                                                                                               'Error %d, Level %d, State %d, Procedure %s, Line %d, Message: ',
                                                                                               '')+'</Value></Instance></Data>' AS StringValue

    

    /*Raise an error: msg_str parameter of RAISERROR will contain
     the original error information.*/
    RAISERROR 
        (
        @ErrorMessage, 
        @ErrorSeverity, 
        1,               
        @ErrorNumber,    /* parameter: original error number.*/
        @ErrorSeverity,  /* parameter: original error severity.*/
        @ErrorState,     /* parameter: original error state.*/
        @ErrorProcedure, /* parameter: original error procedure name.*/
        @ErrorLine       /* parameter: original error line number.*/
        );

END CATCH
