SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET NUMERIC_ROUNDABORT OFF
SET QUOTED_IDENTIFIER ON
SET NOCOUNT ON
BEGIN TRY

    DECLARE @VersionMajor TINYINT,
        @State CHAR(1),
		@Critical INT,
		@Warning INT,
        @ShortMessage VARCHAR(255),
        @OSMemory NUMERIC(19, 0),
        @MaxMemory NUMERIC(19, 0),
		@PLE NUMERIC(19,0)
  
/*Obtain current major version of SQL*/
    SELECT  @VersionMajor=LEFT(CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(100)), CHARINDEX('.', CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(100)))-1)

    IF @VersionMajor IN (9, 10, 11, 12, 13) /*SQL2005-2016*/ 
        BEGIN
            CREATE TABLE #msver
                (
                 index_val INT,
                 name VARCHAR(50),
                 internal_value INT,
                 character_value VARCHAR(255)
                )

            INSERT  #msver
                    EXEC master.dbo.xp_msver 
                        'PhysicalMemory'

            SELECT  @OSMemory=o.internal_value,
                    @MaxMemory=CAST(value_in_use AS INT)
            FROM    sys.configurations s
                    CROSS JOIN #msver o
            WHERE   s.name LIKE '%max server memory%'

			/*If the max is not set or if it is higher than the OS - use the OS*/
			IF @MaxMemory > @OSMemory
				SELECT @MaxMemory = @OSMemory

			SELECT @Critical = CASE WHEN @MaxMemory < 4000 THEN 300 ELSE @MaxMemory / 4096 * 300 END
			SELECT @Warning = @Critical * 1.10
			SELECT @PLE = cntr_value
			FROM sys.dm_os_performance_counters
			WHERE [object_name] LIKE '%Manager%'
			AND [counter_name] = 'Page life expectancy'

			SELECT @PLE = ISNULL(@PLE, 0)

			/*no critical for this monitor - just warning if it remains for a long time*/
			SELECT @State = CASE WHEN @PLE < @Warning THEN '1' ELSE '0' END

/*<Data><Instance Name="default"><Value UofM="" Name="PLE" Warning="$Warning" Critical="$Critical">$AltValue</Value></Instance></Data>*/
            IF @State='0' 
                SELECT  @State+','+'PLE: '+CAST(@PLE AS VARCHAR(100))+' OK|<Data><Instance Name="default"><Value UofM="" Name="PLE" Warning="'+CAST(@Warning AS VARCHAR(100))+'" Critical="'+CAST(@Critical AS VARCHAR(100))+'">'+CAST(@PLE AS VARCHAR(100))+'</Value></Instance></Data>' AS StringValue
            ELSE 
                IF @PLE < @Critical
                    SELECT  @State+','+'PLE: '+CAST(@PLE AS VARCHAR(100))+' CRITICAL|<Data><Instance Name="default"><Value UofM="" Name="PLE" Warning="'+CAST(@Warning AS VARCHAR(100))+'" Critical="'+CAST(@Critical AS VARCHAR(100))+'">'+CAST(@PLE AS VARCHAR(100))+'</Value></Instance></Data>' AS StringValue
                ELSE 
                    SELECT  @State+','+'PLE: '+CAST(@PLE AS VARCHAR(100))+' WARNING|<Data><Instance Name="default"><Value UofM="" Name="PLE" Warning="'+CAST(@Warning AS VARCHAR(100))+'" Critical="'+CAST(@Critical AS VARCHAR(100))+'">'+CAST(@PLE AS VARCHAR(100))+'</Value></Instance></Data>' AS StringValue

/*Clean Up*/
            DROP TABLE #msver
        END
END TRY
BEGIN CATCH
			
		/*http://msdn.microsoft.com/en-us/library/ms179296%28v=SQL.105%29.aspx*/

    DECLARE @ErrorMessage NVARCHAR(4000),
        @ErrorNumber INT,
        @ErrorSeverity INT,
        @ErrorState INT,
        @ErrorLine INT,
        @ErrorProcedure NVARCHAR(200);

    /*Assign variables to error-handling functions that 
     capture information for RAISERROR.*/
    SELECT  @ErrorNumber=ERROR_NUMBER(),
            @ErrorSeverity=ERROR_SEVERITY(),
            @ErrorState=ERROR_STATE(),
            @ErrorLine=ERROR_LINE(),
            @ErrorProcedure=ISNULL(ERROR_PROCEDURE(), '-');

	/*Build the message string that will contain original
     error information.*/
    SELECT  @ErrorMessage=N'Error %d, Level %d, State %d, Procedure %s, Line %d, '+'Message: '+ERROR_MESSAGE();

    SELECT  '3|<Data><Instance Name="default" Type="SQL"><Value Name="Error" UofM="">'+REPLACE(REPLACE(REPLACE(REPLACE(@ErrorMessage, '&', '&amp;'), '<', '&lt;'),
                                                                                                       '>', '&gt;'),
                                                                                               'Error %d, Level %d, State %d, Procedure %s, Line %d, Message: ',
                                                                                               '')+'</Value></Instance></Data>' AS StringValue

    

    /*Raise an error: msg_str parameter of RAISERROR will contain
     the original error information.*/
    RAISERROR 
        (
        @ErrorMessage, 
        @ErrorSeverity, 
        1,               
        @ErrorNumber,    /* parameter: original error number.*/
        @ErrorSeverity,  /* parameter: original error severity.*/
        @ErrorState,     /* parameter: original error state.*/
        @ErrorProcedure, /* parameter: original error procedure name.*/
        @ErrorLine       /* parameter: original error line number.*/
        );

END CATCH      

