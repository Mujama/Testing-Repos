SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET NUMERIC_ROUNDABORT OFF
SET QUOTED_IDENTIFIER ON

SET NOCOUNT ON

BEGIN TRY
	
    DECLARE @IsReceiveEnabled BIT ,
        @IsEnqueueEnabled BIT ,
        @QueueCount TINYINT
   
    SELECT  @IsReceiveEnabled = is_receive_enabled ,
            @IsEnqueueEnabled = is_enqueue_enabled ,
            @QueueCount = COUNT(*)
    FROM    [Apparatus_DBA].[sys].[service_queues]
    WHERE   Name = 'BlockedProcessNotificationQueue'
    GROUP BY is_receive_enabled ,
            is_enqueue_enabled

    IF @QueueCount IS NULL
        BEGIN
            SELECT  '1,BlockedProcessNotificationQueue Does Not Exist|<Data><Instance Name="ServiceQueueEnabled"><Value Name="QueueStatus" UofM="">0</Value></Instance></Data>' AS StringValue
        END
    ELSE
        BEGIN
            IF @IsReceiveEnabled = 1
                AND @IsEnqueueEnabled = 1
                SELECT  '0,BlockedProcessNotificationQueue Is Enabled|<Data><Instance Name="ServiceQueueEnabled"><Value Name="QueueStatus" UofM="">1</Value></Instance></Data>' AS StringValue
            ELSE
                SELECT  '2,BlockedProcessNotificationQueue Is Disabled|<Data><Instance Name="ServiceQueueEnabled"><Value Name="QueueStatus" UofM="">0</Value></Instance></Data>' AS StringValue
        END

END TRY
BEGIN CATCH
			
		/*http://msdn.microsoft.com/en-us/library/ms179296%28v=SQL.105%29.aspx*/

    DECLARE @ErrorMessage NVARCHAR(4000) ,
        @ErrorNumber INT ,
        @ErrorSeverity INT ,
        @ErrorState INT ,
        @ErrorLine INT ,
        @ErrorProcedure NVARCHAR(200);

    /*Assign variables to error-handling functions that 
     capture information for RAISERROR.*/
    SELECT  @ErrorNumber = ERROR_NUMBER() ,
            @ErrorSeverity = ERROR_SEVERITY() ,
            @ErrorState = ERROR_STATE() ,
            @ErrorLine = ERROR_LINE() ,
            @ErrorProcedure = ISNULL(ERROR_PROCEDURE(), '-');

	/*Build the message string that will contain original
     error information.*/
    SELECT  @ErrorMessage = N'' + ERROR_MESSAGE();

    SELECT  '3,Queue Check Failed:' + @ErrorMessage
            + '|<Data><Instance Name="Execution"><Value Name="ExecutionComplete" UofM="">0</Value></Instance></Data>' AS StringValue

END CATCH