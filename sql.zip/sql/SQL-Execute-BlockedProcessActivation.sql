SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET NUMERIC_ROUNDABORT OFF
SET QUOTED_IDENTIFIER ON

SET NOCOUNT ON

BEGIN TRY
	
    DECLARE @SQLToExecute NVARCHAR(MAX)

    SELECT  @SQLToExecute='ALTER PROCEDURE [dbo].[BlockedProcessActivation] WITH ENCRYPTION
AS 
    SET ANSI_NULLS ON
	SET ANSI_PADDING ON
	SET ANSI_WARNINGS ON
	SET ARITHABORT ON
	SET CONCAT_NULL_YIELDS_NULL ON
	SET NUMERIC_ROUNDABORT OFF
	SET QUOTED_IDENTIFIER ON

	DECLARE @Message XML,
        @DialogueID UNIQUEIDENTIFIER,
        @ServiceName NVARCHAR(512),
        @DBName sysname,
        @DBID INT,
        @TransactionID BIGINT,
		@Duration bigint,
		@StartTime datetime,
		@EndTime datetime,
		@BlockedThreshold int

		DECLARE @subject NVARCHAR(1000), @body NVARCHAR(4000)

		SELECT @BlockedThreshold = cast(value as int) from sys.configurations where name like ''blocked process threshold%''

    WHILE 1 = 1
        BEGIN
            BEGIN TRAN
            BEGIN TRY
		
		;
                RECEIVE TOP ( 1 )
			@Message = message_body,
			@DialogueID = conversation_handle,
			@ServiceName = SERVICE_NAME FROM
			dbo.BlockedProcessNotificationQueue
			
                IF @@ROWCOUNT = 0 
                    BEGIN
                        IF @@TRANCOUNT > 0 
                            BEGIN 
                                ROLLBACK ;
                            END  
                        BREAK ;
                    END 

                SELECT  @TransactionID = @Message.value(''/EVENT_INSTANCE[1]/TransactionID[1]'', ''bigint''),
				@Duration = @Message.value(''/EVENT_INSTANCE[1]/Duration[1]'', ''bigint'')/1000/1000,
				@StartTime = @Message.value(''/EVENT_INSTANCE[1]/StartTime[1]'', ''datetime''),
				@EndTime = @Message.value(''/EVENT_INSTANCE[1]/EndTime[1]'', ''datetime'')

                IF @TransactionID = 0 
                    SELECT  @TransactionID = @Message.value(''/EVENT_INSTANCE[1]/EventSequence[1]'', ''bigint'') * 10

                IF NOT EXISTS ( SELECT  ID
                                FROM    dbo.BlockedProcesses
                                WHERE   TransactionID = @TransactionID) 
                    BEGIN
                        INSERT  INTO dbo.BlockedProcesses
                                (
                                  EventMessage,
                                  TransactionID,
								  Duration
                                )
                                SELECT  @Message,
                                        @TransactionID,
										@Duration
                                
                /*Include stuff here to raise alerts*/
						/*
						DECLARE @txt NVARCHAR(4000)

						SELECT @txt = ''Blocked Process in ''+DB_NAME(@Message.value(''/EVENT_INSTANCE[1]/DatabaseID[1]'', ''int''))
						RAISERROR(@txt, 16, 1) WITH LOG*/
						
						
END
                ELSE 
                    BEGIN
                        UPDATE  dbo.BlockedProcesses
                        SET     EventMessage = @Message,
                                FinalEventDate = GETDATE(),
								Duration = @Duration
                        WHERE   TransactionID = @TransactionID

                    END					

                IF @@TRANCOUNT > 0 
                    BEGIN 
                        COMMIT ;
                    END

								/*Include stuff here to raise alerts*/

/*20150122 - KEN - Updated notification so that it will not notify at 60 seconds - only after 5 minutes */
/*20151130 - KEN - Update to not notify at all */
						/*
						IF @Duration > 60+(@BlockedThreshold) AND @Duration%300 >= 60 AND @Duration%300 < 60+(@BlockedThreshold)
						BEGIN
						SELECT @subject = ''Blocked Process ''+CAST(@Duration as varchar(100))+'' seconds in ''+DB_NAME(@Message.value(''/EVENT_INSTANCE[1]/DatabaseID[1]'', ''int'')),
						@body = CAST(@message AS nvarchar(4000))

						EXEC msdb.dbo.sp_notify_operator @Name=''Apparatus_DBA'', @subject=@subject, @body=@body
						END
						*/


            END TRY
            BEGIN CATCH
                IF @@TRANCOUNT > 0 
                    BEGIN 
                        ROLLBACK ;
                    END
				-- write any error in to the event log
                DECLARE @ErrorNumber BIGINT,
                    @ErrorMessage nvarchar(2048),
                    @DatabaseContext sysname
                SELECT  @ErrorNumber = ERROR_NUMBER(),
                        @ErrorMessage = ERROR_MESSAGE(),
                        @DatabaseContext = DB_NAME()
				
				INSERT INTO BlockedProcessActivationErrors (ErrorNumber, ErrorMessage, DatabaseContext)
				VALUES (@ErrorNumber, @ErrorMessage, @DatabaseContext)

            END CATCH ;
        END

'

    EXEC(@SQLToExecute)

	SELECT '0,ExecutionSuccessful|<Data><Instance Name="Execution"><Value Name="ExecutionComplete" UofM="">1</Value></Instance></Data>' AS StringValue

END TRY
BEGIN CATCH
			
		/*http://msdn.microsoft.com/en-us/library/ms179296%28v=SQL.105%29.aspx*/

    DECLARE @ErrorMessage NVARCHAR(4000),
        @ErrorNumber INT,
        @ErrorSeverity INT,
        @ErrorState INT,
        @ErrorLine INT,
        @ErrorProcedure NVARCHAR(200);

    /*Assign variables to error-handling functions that 
     capture information for RAISERROR.*/
    SELECT  @ErrorNumber=ERROR_NUMBER(),
            @ErrorSeverity=ERROR_SEVERITY(),
            @ErrorState=ERROR_STATE(),
            @ErrorLine=ERROR_LINE(),
            @ErrorProcedure=ISNULL(ERROR_PROCEDURE(), '-');

	/*Build the message string that will contain original
     error information.*/
    SELECT  @ErrorMessage=N''+ERROR_MESSAGE();

    SELECT  '1,ExecutionFailed:'+@ErrorMessage+'|<Data><Instance Name="Execution"><Value Name="ExecutionComplete" UofM="">0</Value></Instance></Data>' AS StringValue

END CATCH