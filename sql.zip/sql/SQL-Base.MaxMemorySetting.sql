/*######################################
SQL-Base.MaxMemory			
Author: Kyle Neier
Created: 20130807
Validated Versions: 2005, 2008, 2008R2, 2012
Validated Editions: Standard, Enterprise

Synopsis: Interrogates instance for current
max memory setting and aligns with Apparatus
standard.

20141020: Replaced the last calculation in the nested IF,
		  @SQLMaxAllowed=(@OSMemory-(@OSMemory*256)), with
		  @SQLMaxAllowed=CEILING((@OSMemory - (@OSMemory*.25)))
		  to prevent incorrect results on servers with less
		  than 4GB of RAM

######################################*/
SET NOCOUNT ON
BEGIN TRY

    DECLARE @VersionMajor TINYINT,
        @State CHAR(1),
        @ShortMessage VARCHAR(255),
        @OSMemory NUMERIC(19, 2),
        @MaxMemory NUMERIC(19, 2),
        @SQLMaxAllowed NUMERIC(19, 2)
  
/*Obtain current major version of SQL*/
    SELECT  @VersionMajor=LEFT(CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(100)), CHARINDEX('.', CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(100)))-1)

    IF @VersionMajor IN (9, 10, 11, 12) /*SQL2005-2014*/ 
        BEGIN
            CREATE TABLE #msver
                (
                 index_val INT,
                 name VARCHAR(50),
                 internal_value INT,
                 character_value VARCHAR(255)
                )

            INSERT  #msver
                    EXEC master.dbo.xp_msver 
                        'PhysicalMemory'

            SELECT  @OSMemory=o.internal_value,
                    @MaxMemory=CAST(value_in_use AS INT)
            FROM    sys.configurations s
                    CROSS JOIN #msver o
            WHERE   s.name LIKE '%max server memory%'

            IF @OSMemory>=65536 /*64GB*/ 
                SELECT  @SQLMaxAllowed=(@OSMemory-(((@OSMemory-65536)/16384)+10240)) /*(@OSMemory - (((@OSMemory-64)/16)+10))*/
            ELSE 
                IF @OSMemory>=16384 
                    SELECT  @SQLMaxAllowed=(@OSMemory-(((@OSMemory-16384)/16384)+4096)) /*(@OSMemory-(((@OSMemory-16)/8)+4))*/
                ELSE 
                    IF @OSMemory>=4096 
                        SELECT  @SQLMaxAllowed=(@OSMemory-(((@OSMemory-4096)/4096)+1024)) /*(@OSMemory-(((@OSMemory-4)/4)+1))*/
                    ELSE 
						SELECT @SQLMaxAllowed=CEILING((@OSMemory - (@OSMemory*.25)))
						/* @SQLMaxAllowed=(@OSMemory-(@OSMemory*256))*/ /*(@OSMemory - (@OSMemory*.25))*/

/*Leave this much for OS

.25GB for every 1GB up to 4GB,
1GB for every 4GB up to 16,
1GB for every 8GB up to 64
1GB for every 16GB after 64
(x-64)/16
(x-64-48)/8
(x-64-48-8)/4
(x-64-48-8-4)

*/

            SELECT  @State=CASE WHEN @MaxMemory>@OSMemory THEN '2'
                                WHEN @MaxMemory>@SQLMaxAllowed THEN '1'
                                ELSE '0'
                           END
            DECLARE @x XML 

            SET @x=(SELECT  (SELECT 'default' AS [Instance/@Name],
                                    'SQL MEMORY' AS [Instance/@Type],
                                    @State AS [Instance/@State],
                                    (SELECT *
                                     FROM   (SELECT 'SQL MAX MEMORY SETTING' AS [Value/@Name],
                                                    'MB' AS [Value/@UofM],
                                                    CAST(CAST(@SQLMaxAllowed AS INT) AS VARCHAR(100)) AS [Value/@Warning],
                                                    CAST(CAST(@OSMemory AS INT) AS VARCHAR(100)) AS [Value/@Critical],
                                                    CAST(CAST(@MaxMemory AS INT) AS VARCHAR(100)) AS [Value]
                                             UNION ALL
                                             SELECT 'OS PHYSICAL MEMORY' AS [Value/@Name],
                                                    'MB' AS [Value/@UofM],
                                                    '' AS [Value/@Warning],
                                                    '' AS [Value/@Critical],
                                                    CAST(CAST(@OSMemory AS INT) AS VARCHAR(100)) AS [Value]
                                             UNION ALL
                                             SELECT 'SQL MAX MEMORY ALLOWED' AS [Value/@Name],
                                                    'MB' AS [Value/@UofM],
                                                    '' AS [Value/@Warning],
                                                    '' AS [Value/@Critical],
                                                    CAST(CAST(@SQLMaxAllowed AS INT) AS VARCHAR(100)) AS [Value]) AS a
                                    FOR
                                     XML PATH(''),
                                         TYPE) Instance
                            FOR
                             XML PATH(''),
                                 TYPE)
                FOR XML PATH('Data'),
                        TYPE)

            IF @State='0' 
                SELECT  @ShortMessage='SQL MAX MEMORY OK: '+CAST(CAST(@MaxMemory AS INT) AS VARCHAR(100))+'MB; OS: '
                        +CAST(CAST(@OSMemory AS INT) AS VARCHAR(100))+'MB'
            ELSE 
                IF @State='1' 
                    SELECT  @ShortMessage='SQL MAX MEMORY WARNING:'+CAST(CAST(@MaxMemory AS INT) AS VARCHAR(100))+'MB; OS: '
                            +CAST(CAST(@OSMemory AS INT) AS VARCHAR(100))+'MB'
                ELSE 
                    SELECT  @ShortMessage='SQL MAX MEMORY CRITICAL:'+CAST(CAST(@MaxMemory AS INT) AS VARCHAR(100))+'MB; OS: '
                            +CAST(CAST(@OSMemory AS INT) AS VARCHAR(100))+'MB'


            SELECT  @State+','+@ShortMessage+'|'+CAST(@x AS VARCHAR(MAX)) AS StringValue

/*Clean Up*/
            DROP TABLE #msver
        END
END TRY
BEGIN CATCH
			
		/*http://msdn.microsoft.com/en-us/library/ms179296%28v=SQL.105%29.aspx*/

    DECLARE @ErrorMessage NVARCHAR(4000),
        @ErrorNumber INT,
        @ErrorSeverity INT,
        @ErrorState INT,
        @ErrorLine INT,
        @ErrorProcedure NVARCHAR(200);

    /*Assign variables to error-handling functions that 
     capture information for RAISERROR.*/
    SELECT  @ErrorNumber=ERROR_NUMBER(),
            @ErrorSeverity=ERROR_SEVERITY(),
            @ErrorState=ERROR_STATE(),
            @ErrorLine=ERROR_LINE(),
            @ErrorProcedure=ISNULL(ERROR_PROCEDURE(), '-');

	/*Build the message string that will contain original
     error information.*/
    SELECT  @ErrorMessage=N'Error %d, Level %d, State %d, Procedure %s, Line %d, '+'Message: '+ERROR_MESSAGE();

    SELECT  '3|<Data><Instance Name="default" Type="SQL"><Value Name="Error" UofM="">'+REPLACE(REPLACE(REPLACE(REPLACE(@ErrorMessage, '&', '&amp;'), '<', '&lt;'),
                                                                                                       '>', '&gt;'),
                                                                                               'Error %d, Level %d, State %d, Procedure %s, Line %d, Message: ',
                                                                                               '')+'</Value></Instance></Data>' AS StringValue

    

    /*Raise an error: msg_str parameter of RAISERROR will contain
     the original error information.*/
    RAISERROR 
        (
        @ErrorMessage, 
        @ErrorSeverity, 
        1,               
        @ErrorNumber,    /* parameter: original error number.*/
        @ErrorSeverity,  /* parameter: original error severity.*/
        @ErrorState,     /* parameter: original error state.*/
        @ErrorProcedure, /* parameter: original error procedure name.*/
        @ErrorLine       /* parameter: original error line number.*/
        );

END CATCH      

