if(!(Test-Path variable:\Warn)){[double]$Warn=0}
if(!(Test-Path variable:\Crit)){[double]$Crit=0}
if(!(Test-Path variable:\Instance)){[string]$Instance="DEFAULT"}

$ErrorActionPreference = "Stop"

function Ret{param($T,$N,$V,$W,$C);@"
$V,$W,$C|<Data><Instance Name="default"><Value UofM="" Name="$N" Warning="$W" Critical="$C">$V</Value></Instance></Data>
"@}

function Ret_1I1V{param($ValueName,$State,$Warning,$Critical,$AltValue);
if($AltValue -eq $null){$AltValue=$State};@"
$State|<Data><Instance Name="default"><Value UofM="" Name="$ValueName" Warning="$Warning" Critical="$Critical">$AltValue</Value></Instance></Data>
"@}

try{
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | out-null
if($Instance -eq "DEFAULT")
{$PerfName="SQLServer";$SvcName="MSSQLSERVER";$IName="."}
else{$PerfName="MSSQL`$$Instance";$SvcName=$PerfName;$IName=".\$Instance"}


$s = New-Object Microsoft.SqlServer.Management.Smo.Server $IName

$Buff = $s.Configuration.MaxServerMemory.ConfigValue * 1024

if($Buff -eq 2147483647*1024){$Buff=(gwmi win32_computersystem).TotalPhysicalMemory}
if($Crit -eq 0){if($Buff -lt 4GB){$Crit=300}else{$Crit=$Buff/4GB*300}}
if($Warn -eq 0){$Warn=$Crit*1.10}
$PLE=(Get-Counter "\$PerfName`:Buffer Manager\Page life expectancy").CounterSamples[0].CookedValue

function Get-State{
param([double]$Value,[double]$Warn,[double]$Crit)
	<#	3 states: 1 < Warn > 2 < Crit > 3#>
	if($Warn -gt $Crit)
	{
		if($Value -lt $Crit){1}
		elseif($Value -gt $Warn) {0}
		else{1}
	}
	else
	{
		if($Value -ge $Crit){1}
		elseif($Value -lt $Warn){0}
		else{1}
	}
}

Ret_1I1V "PLE" (Get-State $PLE $Warn $Crit) $Warn.ToString("F0") $Crit.ToString("F0") $PLE

#Ret "PLE" $PLE $Warn.ToString("F0") $Crit.ToString("F0")
}catch{Ret_1I1V "Error" 3 0 1 $("$($_.Exception);$($_.InvocationInfo.ScriptLineNumber))".Replace('&', '&amp;').Replace('<', '&lt;').Replace('>', '&gt;'));throw}
