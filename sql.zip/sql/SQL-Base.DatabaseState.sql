/*######################################
SQL-Base.DatabaseState			
Author: Kyle Neier
Created: 20130808
Validated Versions: 2005, 2008, 2008R2, 2012
Validated Editions: Standard, Enterprise

Synopsis: Interrogates each database 
for the state of the database.

Will warn if 2,3 | Crit if 4,5

0 = ONLINE
1 = RESTORING
2 = RECOVERING
3 = RECOVERY_PENDING
4 = SUSPECT
5 = EMERGENCY
6 = OFFLINE
7 = COPYING (Applies to Windows Azure SQL Database)

######################################*/

SET NOCOUNT ON
    

BEGIN TRY

/*Init some variables*/
    DECLARE @VersionMajor TINYINT

/*Obtain current major version of SQL*/
    SELECT  @VersionMajor=LEFT(CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(100)), CHARINDEX('.', CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(100)))-1)
    IF @VersionMajor IN (9, 10, 11, 12) /*SQL2005-2014*/ 
        BEGIN
	
/*Build out the XML for the data portion*/
            DECLARE @x XML 
			
            SET @x=(SELECT  (SELECT db.Name AS [Instance/@Name],
                                    'SQL Database' AS [Instance/@Type],
                                    CASE state
                                      WHEN 2 THEN 1
                                      WHEN 3 THEN 1
                                      WHEN 4 THEN 2
                                      WHEN 5 THEN 2
                                      ELSE 0
                                    END AS [Instance/@State],
                                    (SELECT *
                                     FROM   (SELECT 'DatabaseState' AS [Value/@Name],
                                                    '' AS [Value/@UofM],
                                                    CAST(idb.state AS VARCHAR(100)) AS [Value]
                                             FROM   sys.databases idb
                                             WHERE  idb.name=db.name
                                             UNION ALL
                                             SELECT 'DatabaseState_Desc' AS [Value/@Name],
                                                    '' AS [Value/@UofM],
                                                    CAST(idb.state_desc AS VARCHAR(100)) AS [Value]
                                             FROM   sys.databases idb
                                             WHERE  idb.name=db.name) AS a
                                    FOR
                                     XML PATH(''),
                                         TYPE) Instance
                             FROM   sys.databases db
                            FOR
                             XML PATH(''),
                                 TYPE)
                FOR XML PATH('Data'),
                        TYPE)


/*Init some more local variables*/
            DECLARE @WarningCount INT,
                @CriticalCount INT,
                @ShortMessage VARCHAR(255),
                @State CHAR(1)

/*Store the count of occurences*/
            SELECT  @WarningCount=COUNT(DISTINCT Name)
            FROM    sys.databases
            WHERE   state IN (2, 3)


            SELECT  @CriticalCount=COUNT(DISTINCT Name)
            FROM    sys.databases
            WHERE   state IN (4, 5)


/*Materialize the state and short message*/
            IF @WarningCount=0
                AND @CriticalCount=0 
                SELECT  @State=0,
                        @ShortMessage='ALL DATABASE STATE OK'
            ELSE 
                IF @CriticalCount>0 
                    SELECT  @State=2,
                            @ShortMessage=CAST(@CriticalCount AS VARCHAR(5))+' DATABASES IN CRITICAL STATE, '+CAST(@WarningCount AS VARCHAR(5))
                            +' DATABASES ARE IN WARNING STATE'
                ELSE 
                    SELECT  @State=1,
                            @ShortMessage=CAST(@WarningCount AS VARCHAR(5))+' DATABASES ARE IN WARNING STATE'


/*Return the State, Message, and XML*/
            SELECT  @State+','+@ShortMessage+'|'+CAST(@x AS VARCHAR(MAX)) AS StringValue
        END
END TRY
BEGIN CATCH
			
		/*http://msdn.microsoft.com/en-us/library/ms179296%28v=SQL.105%29.aspx*/

    DECLARE @ErrorMessage NVARCHAR(4000),
        @ErrorNumber INT,
        @ErrorSeverity INT,
        @ErrorState INT,
        @ErrorLine INT,
        @ErrorProcedure NVARCHAR(200);

    /*Assign variables to error-handling functions that 
     capture information for RAISERROR.*/
    SELECT  @ErrorNumber=ERROR_NUMBER(),
            @ErrorSeverity=ERROR_SEVERITY(),
            @ErrorState=ERROR_STATE(),
            @ErrorLine=ERROR_LINE(),
            @ErrorProcedure=ISNULL(ERROR_PROCEDURE(), '-');

	/*Build the message string that will contain original
     error information.*/
    SELECT  @ErrorMessage=N'Error %d, Level %d, State %d, Procedure %s, Line %d, '+'Message: '+ERROR_MESSAGE();

    SELECT  '3|<Data><Instance Name="default" Type="SQL"><Value Name="Error" UofM="">'+REPLACE(REPLACE(REPLACE(REPLACE(@ErrorMessage, '&', '&amp;'), '<', '&lt;'),
                                                                                                       '>', '&gt;'),
                                                                                               'Error %d, Level %d, State %d, Procedure %s, Line %d, Message: ',
                                                                                               '')+'</Value></Instance></Data>' AS StringValue

    

    /*Raise an error: msg_str parameter of RAISERROR will contain
     the original error information.*/
    RAISERROR 
        (
        @ErrorMessage, 
        @ErrorSeverity, 
        1,               
        @ErrorNumber,    /* parameter: original error number.*/
        @ErrorSeverity,  /* parameter: original error severity.*/
        @ErrorState,     /* parameter: original error state.*/
        @ErrorProcedure, /* parameter: original error procedure name.*/
        @ErrorLine       /* parameter: original error line number.*/
        );

END CATCH      
